# Nexus Client — Fabric 1.21.11

Nexus Client is a client-side Fabric mod with a modular ClickGUI, configurable keybinds, HUD elements, and saved PvP profiles.

## Current feature inventory

The source currently registers **70 modules**. This is the count in this ZIP; it is not 150 yet. The list is grouped below so missing work is visible instead of being hidden behind placeholder entries.

- **Combat (9):** AutoTotem, AutoArmor, KillAura, TriggerBot, AimAssist, AutoClicker, Surround, AutoWeapon, AutoBlock
- **Movement (22):** Fly, Speed, NoFall, AutoSprint, Step, HighJump, LongJump, AirJump, Jesus, Spider, AutoWalk, Dolphin, Glide, AutoJump, SafeWalk, Sneak, ElytraFly, AutoSwim, Bhop, FastFall, FastLadder, BoatFly
- **Player (9):** AutoEat, AutoRespawn, AntiAFK, AutoTool, ChestStealer, AutoReplenish, AutoFish, AutoMine, ItemThrower
- **World (3):** Scaffold, Nuker, AutoTorch
- **Render (3):** Fullbright, Zoom, FovChanger
- **HUD (24):** FPS, CPS, Ping, XYZ, SpeedHUD, Clock, TotemCounter, CrystalCounter, PotionCounter, EntityCounter, PlayerCounter, Session, WorldTime, ServerInfo, FallDistance, ArmorHUD, PotionHUD, TargetHUD, Keystrokes, Cooldown, CustomCrosshair, DeathLocation, Direction, DayCounter

## Controls

- **Right Shift:** open/close ClickGUI
- **Left click:** toggle module / activate profile
- **Right click:** open module settings / save profile
- **Middle click:** bind a key; press Escape to clear
- **Drag category header:** move its panel
- **Right-click category header:** collapse/expand panel

## Build on GitHub from a phone

This repository includes `.github/workflows/build.yml`; a local Gradle installation or wrapper is not required for the GitHub Actions build.

1. Upload the contents of this folder to a GitHub repository (the `.github` folder must be included).
2. Open the repository's **Actions** tab.
3. Select **Build Nexus Client** and tap **Run workflow**, or push a commit to `main`/`master`.
4. Wait for the workflow to finish successfully.
5. Open the completed run, find **Artifacts**, and download `nexus-client-...`.
6. Extract the artifact and copy the mod JAR into the Minecraft `mods` folder. Install a matching Fabric Loader and Fabric API for Minecraft 1.21.11.

The workflow uses Java 21 and Gradle 9.2.1. A successful artifact upload is the build confirmation; source inspection alone is not proof that the mod compiles.

## Notes

- The project targets Minecraft 1.21.11, Java 21, Fabric Loader, and Fabric API as declared in `gradle.properties`.
- Combat and movement automation may violate multiplayer-server rules. Use only in single-player or on servers where the owner explicitly permits these features.
- This archive has not yet been validated by a successful Gradle build in this environment. Run the GitHub Actions workflow to obtain the real compile result.

## 100 ek HUD göstergesi

`TelemetryPack` ile 100 ayrı, açılıp kapatılabilir ve ClickGUI üzerinden konum/renk ayarı yapılabilen salt-okunur gösterge eklendi. Bunlar sunucuya özel ağ paketi göndermez; oyuncu, envanter, dünya ve bağlantı durumunu ekranda gösterir.

Örnek göstergeler: sağlık ve açlık durumu, XP, koordinatlar, chunk konumu, yaw/pitch, yatay-dikey hız, hareket durumu, hotbar slotları ve adetleri, envanter doluluğu, eldeki eşyanın dayanıklılığı, dünya saati/hava durumu, ışık seviyesi, ayak altındaki blok, FPS ve ping.

Göstergeler varsayılan olarak kapalıdır. `Right Shift` ile ClickGUI'yi açıp `HUD` kategorisinden istediklerini etkinleştirebilirsin. Çok sayıda göstergiyi aynı anda açarsan Y konumlarını ayarlayarak ekranda düzenle.
