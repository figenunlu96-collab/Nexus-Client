package com.nexus.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

public final class PlayerUtil {
    private PlayerUtil() {}

    public static int hotbarSlot(ClientPlayerEntity p, Item item) {
        for (int i = 0; i < 9; i++) if (p.getInventory().getStack(i).isOf(item)) return i;
        return -1;
    }

    public static boolean moving(MinecraftClient mc) {
        return mc.options.forwardKey.isPressed() || mc.options.backKey.isPressed()
            || mc.options.leftKey.isPressed() || mc.options.rightKey.isPressed();
    }

    /** `base` bloğunun `face` yüzüne, hotbar'daki `slot` içindeki bloğu koyar. */
    public static void placeAgainst(MinecraftClient mc, ClientPlayerEntity p, int slot, BlockPos base, Direction face) {
        if (mc.interactionManager == null) return;
        Vec3d hitPos = Vec3d.ofCenter(base).add(Vec3d.of(face.getVector()).multiply(0.5));
        BlockHitResult hit = new BlockHitResult(hitPos, face, base, false);
        int prev = p.getInventory().getSelectedSlot();
        p.getInventory().setSelectedSlot(slot);
        mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, hit);
        p.swingHand(Hand.MAIN_HAND);
        p.getInventory().setSelectedSlot(prev);
    }
}
