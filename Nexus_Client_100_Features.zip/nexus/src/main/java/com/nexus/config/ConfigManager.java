package com.nexus.config;

import com.google.gson.*;
import com.nexus.NexusClient;
import com.nexus.module.Module;
import com.nexus.setting.*;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.*;

public class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("nexus-client.json");
    private static final Path PROFILE_DIR = FabricLoader.getInstance().getConfigDir().resolve("nexus-profiles");

    /** Tüm modüllerin durumunu (açık/kapalı, tuş, ayarlar) JSON'a çevirir. */
    public static JsonObject snapshot() {
        JsonObject root = new JsonObject();
        for (Module m : NexusClient.modules.all()) {
            JsonObject o = new JsonObject();
            o.addProperty("enabled", m.isEnabled());
            o.addProperty("key", m.getKey());
            JsonObject s = new JsonObject();
            for (Setting<?> st : m.getSettings()) {
                if (st instanceof NumberSetting n) s.addProperty(st.name, n.get());
                else if (st instanceof BooleanSetting b) s.addProperty(st.name, b.get());
                else if (st instanceof ModeSetting md) s.addProperty(st.name, md.get());
            }
            o.add("settings", s);
            root.add(m.name, o);
        }
        return root;
    }

    /** JSON'daki durumu modüllere uygular (kapalı olanları da kapatır). */
    public static void apply(JsonObject root) {
        for (Module m : NexusClient.modules.all()) {
            if (!root.has(m.name)) continue;
            JsonObject o = root.getAsJsonObject(m.name);
            if (o.has("key")) m.setKey(o.get("key").getAsInt());
            if (o.has("settings")) {
                JsonObject s = o.getAsJsonObject("settings");
                for (Setting<?> st : m.getSettings()) {
                    if (!s.has(st.name)) continue;
                    if (st instanceof NumberSetting n) n.set(s.get(st.name).getAsDouble());
                    else if (st instanceof BooleanSetting b) b.set(s.get(st.name).getAsBoolean());
                    else if (st instanceof ModeSetting md) md.set(s.get(st.name).getAsString());
                }
            }
            if (o.has("enabled")) m.setEnabled(o.get("enabled").getAsBoolean());
        }
    }

    public static void save() {
        try {
            Files.createDirectories(FILE.getParent());
            Path temp = FILE.resolveSibling(FILE.getFileName() + ".tmp");
            Files.writeString(temp, GSON.toJson(snapshot()));
            try {
                Files.move(temp, FILE, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ignored) {
                Files.move(temp, FILE, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (Exception e) {
            NexusClient.LOGGER.error("Config kaydedilemedi", e);
        }
    }

    public static void load() {
        try {
            if (!Files.exists(FILE)) return;
            apply(JsonParser.parseString(Files.readString(FILE)).getAsJsonObject());
        } catch (Exception e) {
            NexusClient.LOGGER.error("Config yüklenemedi", e);
        }
    }

    // ---------- profiller ----------
    private static String safeProfileName(String name) {
        if (name == null) throw new IllegalArgumentException("Profil adı boş olamaz");
        String safe = name.trim().replaceAll("[^a-zA-Z0-9_-]", "_");
        if (safe.isEmpty() || safe.length() > 32) throw new IllegalArgumentException("Geçersiz profil adı");
        return safe;
    }

    public static void writeProfile(String name) {
        try {
            Files.createDirectories(PROFILE_DIR);
            Path target = PROFILE_DIR.resolve(safeProfileName(name) + ".json");
            Path temp = target.resolveSibling(target.getFileName() + ".tmp");
            Files.writeString(temp, GSON.toJson(snapshot()));
            try {
                Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ignored) {
                Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (Exception e) {
            NexusClient.LOGGER.error("Profil kaydedilemedi: " + name, e);
        }
    }

    /** Profil dosyası yoksa null döner. */
    public static JsonObject readProfile(String name) {
        try {
            Path f = PROFILE_DIR.resolve(safeProfileName(name) + ".json");
            if (!Files.exists(f)) return null;
            return JsonParser.parseString(Files.readString(f)).getAsJsonObject();
        } catch (Exception e) {
            NexusClient.LOGGER.error("Profil okunamadı: " + name, e);
            return null;
        }
    }
}
