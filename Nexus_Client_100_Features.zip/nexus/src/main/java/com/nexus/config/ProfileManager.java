package com.nexus.config;

import com.google.gson.JsonObject;
import com.nexus.NexusClient;
import com.nexus.module.Module;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/**
 * PvP profilleri. Her profil kendi modül durumunu, ayarlarını ve HUD düzenini saklar.
 * Sağ tıkla kaydedilmiş profil varsa o yüklenir; yoksa varsayılan ön ayar uygulanır.
 */
public class ProfileManager {
    public static String active = "";
    private static final Map<String, Set<String>> PRESETS = new LinkedHashMap<>();

    static {
        PRESETS.put("Crystal", Set.of("AutoTotem", "AutoArmor", "TotemCounter", "CrystalCounter", "CPS", "Ping", "ArmorHUD"));
        PRESETS.put("Sword",   Set.of("AutoTotem", "AutoArmor", "CPS", "Cooldown", "TargetHUD", "ArmorHUD", "PotionHUD"));
        PRESETS.put("Axe",     Set.of("AutoTotem", "AutoArmor", "Cooldown", "TargetHUD", "ArmorHUD", "CPS"));
        PRESETS.put("Pot",     Set.of("AutoTotem", "AutoArmor", "PotionHUD", "PotionCounter", "ArmorHUD", "TotemCounter"));
        PRESETS.put("Mace",    Set.of("AutoTotem", "AutoArmor", "TargetHUD", "FallDistance", "Cooldown", "ArmorHUD"));
        PRESETS.put("Bow",     Set.of("AutoTotem", "AutoArmor", "TargetHUD", "CustomCrosshair", "ArmorHUD", "Ping"));
    }

    public static Set<String> names() { return PRESETS.keySet(); }

    public static void switchTo(String name) {
        JsonObject saved = ConfigManager.readProfile(name);
        if (saved != null) {
            ConfigManager.apply(saved);
        } else {
            Set<String> on = PRESETS.getOrDefault(name, Set.of());
            for (Module m : NexusClient.modules.all()) m.setEnabled(on.contains(m.name));
        }
        active = name;
        ConfigManager.save();
    }

    public static void saveCurrent(String name) {
        ConfigManager.writeProfile(name);
        active = name;
    }
}
