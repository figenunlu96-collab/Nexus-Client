package com.nexus.module.hud;

import net.minecraft.client.gui.screen.DeathScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;

/** Bilgi amaçlı küçük HUD bileşenleri. */
public final class Info {
    private Info() {}

    public static class DeathLocation extends HudModule {
        private BlockPos last = null;
        private boolean recorded = false;

        public DeathLocation() { super("DeathLocation", "Son ölüm koordinatı", 220); }

        @Override
        public void onTick() {
            ClientPlayerEntity p = mc.player;
            if (p == null) return;
            if (mc.currentScreen instanceof DeathScreen) {
                if (!recorded) { last = p.getBlockPos(); recorded = true; }
            } else recorded = false;
        }

        @Override
        public String text() {
            return last == null ? "Death: -" : "Death: " + last.getX() + " " + last.getY() + " " + last.getZ();
        }
    }

    public static class Direction extends HudModule {
        public Direction() { super("Direction", "Baktığın yön", 232); }

        @Override
        public String text() {
            ClientPlayerEntity p = mc.player;
            if (p == null) return "";
            return String.format("Facing: %s (%.0f)", p.getHorizontalFacing().toString(), MathHelper.wrapDegrees(p.getYaw()));
        }
    }

    public static class DayCounter extends HudModule {
        public DayCounter() { super("DayCounter", "Oyun içi gün sayısı", 244); }

        @Override
        public String text() { return mc.world == null ? "" : "Day: " + (mc.world.getTimeOfDay() / 24000L); }
    }
}
