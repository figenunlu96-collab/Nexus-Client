package com.nexus.module.movement;

import com.nexus.module.Category;
import com.nexus.module.Module;
import com.nexus.setting.NumberSetting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

public class HighJump extends Module {
    private final NumberSetting height = add(new NumberSetting("Height", 0.8, 0.42, 2.0, 0.05));
    private boolean wasOnGround = true;

    public HighJump() { super("HighJump", "Daha yüksek zıplatır", Category.MOVEMENT); }

    @Override public String getInfo() { return String.format("%.2f", height.get()); }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        if (wasOnGround && !p.isOnGround() && mc.options.jumpKey.isPressed()) {
            Vec3d v = p.getVelocity();
            p.setVelocity(v.x, height.get(), v.z);
        }
        wasOnGround = p.isOnGround();
    }
}
