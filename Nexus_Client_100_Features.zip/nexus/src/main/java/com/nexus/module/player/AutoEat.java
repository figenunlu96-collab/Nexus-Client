package com.nexus.module.player;

import com.nexus.module.Category;
import com.nexus.module.Module;
import com.nexus.setting.NumberSetting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

/** Açlık eşiğin altına düşünce hotbar'daki yiyeceği yer, sonra eski slota döner. */
public class AutoEat extends Module {
    private final NumberSetting threshold = add(new NumberSetting("Hunger", 14, 1, 19, 1));
    private boolean eating = false;
    private int prevSlot = -1;

    public AutoEat() { super("AutoEat", "Acıkınca otomatik yemek yer", Category.PLAYER); }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        if (mc.currentScreen != null) { if (eating) stop(p); return; }

        int hunger = p.getHungerManager().getFoodLevel();

        if (!eating && hunger <= threshold.get().intValue()) {
            int slot = findFood(p);
            if (slot >= 0) {
                prevSlot = p.getInventory().getSelectedSlot();
                p.getInventory().setSelectedSlot(slot);
                eating = true;
            }
        }

        if (eating) {
            if (hunger >= 20 || !isFood(p.getMainHandStack())) stop(p);
            else mc.options.useKey.setPressed(true);
        }
    }

    private void stop(ClientPlayerEntity p) {
        mc.options.useKey.setPressed(false);
        if (prevSlot >= 0) p.getInventory().setSelectedSlot(prevSlot);
        prevSlot = -1;
        eating = false;
    }

    @Override
    protected void onDisable() {
        if (eating && mc.player != null) stop(mc.player);
    }

    private int findFood(ClientPlayerEntity p) {
        for (int i = 0; i < 9; i++) if (isFood(p.getInventory().getStack(i))) return i;
        return -1;
    }

    private boolean isFood(ItemStack s) {
        if (s.isEmpty() || !s.contains(DataComponentTypes.FOOD)) return false;
        return !(s.isOf(Items.GOLDEN_APPLE) || s.isOf(Items.ENCHANTED_GOLDEN_APPLE)
              || s.isOf(Items.PUFFERFISH) || s.isOf(Items.ROTTEN_FLESH)
              || s.isOf(Items.SPIDER_EYE) || s.isOf(Items.POISONOUS_POTATO)
              || s.isOf(Items.CHORUS_FRUIT));
    }
}
