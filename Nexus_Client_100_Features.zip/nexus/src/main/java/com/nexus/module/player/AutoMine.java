package com.nexus.module.player;

import com.nexus.module.Category;
import com.nexus.module.Module;

/** Sol tık tuşunu sürekli basılı tutar (bloğa bakarken kazmaya devam eder). */
public class AutoMine extends Module {
    public AutoMine() { super("AutoMine", "Sürekli kazar", Category.PLAYER); }

    @Override
    public void onTick() {
        if (mc.player != null && mc.currentScreen == null) mc.options.attackKey.setPressed(true);
    }

    @Override
    protected void onDisable() { mc.options.attackKey.setPressed(false); }
}
