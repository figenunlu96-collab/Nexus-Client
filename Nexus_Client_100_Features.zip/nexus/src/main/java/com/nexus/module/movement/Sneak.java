package com.nexus.module.movement;

import com.nexus.module.Category;
import com.nexus.module.Module;

public class Sneak extends Module {
    public Sneak() { super("Sneak", "Sürekli eğilir", Category.MOVEMENT); }

    @Override
    public void onTick() {
        if (mc.player != null && mc.currentScreen == null) mc.options.sneakKey.setPressed(true);
    }

    @Override
    protected void onDisable() { mc.options.sneakKey.setPressed(false); }
}
