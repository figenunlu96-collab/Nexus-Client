package com.nexus.module.movement;

import com.nexus.module.Category;
import com.nexus.module.Module;
import com.nexus.setting.NumberSetting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.Items;
import net.minecraft.util.math.Vec3d;

/** Elytra ile süzülürken ileri tuşuna basınca baktığın yöne ivme verir. */
public class ElytraFly extends Module {
    private final NumberSetting boost = add(new NumberSetting("Boost", 0.05, 0.01, 0.3, 0.01));

    public ElytraFly() { super("ElytraFly", "Elytra'yı hızlandırır", Category.MOVEMENT); }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null || !p.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA)) return;
        String pose = p.getPose().name();
        if (!(pose.equals("GLIDING") || pose.equals("FALL_FLYING"))) return;
        if (!mc.options.forwardKey.isPressed()) return;
        Vec3d look = p.getRotationVector();
        p.setVelocity(p.getVelocity().add(look.multiply(boost.get())));
    }
}
