package com.nexus.module.player;

import com.nexus.module.Category;
import com.nexus.module.Module;
import net.minecraft.block.BlockState;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;

/** Blok kırarken hotbar'daki en hızlı aleti seçer. */
public class AutoTool extends Module {
    public AutoTool() { super("AutoTool", "Blok için en iyi aleti seçer", Category.PLAYER); }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.currentScreen != null) return;
        if (!mc.options.attackKey.isPressed()) return;
        if (mc.crosshairTarget == null || mc.crosshairTarget.getType() != HitResult.Type.BLOCK) return;

        BlockState st = mc.world.getBlockState(((BlockHitResult) mc.crosshairTarget).getBlockPos());
        int best = -1;
        float bestSpeed = 1.0f;
        for (int i = 0; i < 9; i++) {
            float sp = p.getInventory().getStack(i).getMiningSpeedMultiplier(st);
            if (sp > bestSpeed) { bestSpeed = sp; best = i; }
        }
        if (best >= 0 && best != p.getInventory().getSelectedSlot()) {
            p.getInventory().setSelectedSlot(best);
        }
    }
}
