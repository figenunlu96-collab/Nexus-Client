package com.nexus.module.movement;

import com.nexus.module.Category;
import com.nexus.module.Module;
import com.nexus.setting.BooleanSetting;
import com.nexus.setting.NumberSetting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

import org.lwjgl.glfw.GLFW;

public class Speed extends Module {
    private final NumberSetting speed = add(new NumberSetting("Speed", 0.4, 0.1, 2.0, 0.05));
    private final BooleanSetting onlyGround = add(new BooleanSetting("OnlyGround", false));

    public Speed() {
        super("Speed", "Yerde hızlı koşturur", Category.MOVEMENT);
        setKey(GLFW.GLFW_KEY_V);
    }

    @Override public String getInfo() { return String.format("%.2f", speed.get()); }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        if (onlyGround.get() && !p.isOnGround()) return;

        double yaw = Math.toRadians(p.getYaw());
        double fx = -Math.sin(yaw), fz = Math.cos(yaw);
        double rx = Math.cos(yaw), rz = Math.sin(yaw);

        double mx = 0, mz = 0;
        if (mc.options.forwardKey.isPressed()) { mx += fx; mz += fz; }
        if (mc.options.backKey.isPressed())    { mx -= fx; mz -= fz; }
        if (mc.options.leftKey.isPressed())    { mx -= rx; mz -= rz; }
        if (mc.options.rightKey.isPressed())   { mx += rx; mz += rz; }

        double len = Math.sqrt(mx * mx + mz * mz);
        if (len == 0) return;

        double s = speed.get();
        Vec3d v = p.getVelocity();
        p.setVelocity(mx / len * s, v.y, mz / len * s);
    }
}
