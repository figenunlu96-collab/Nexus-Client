package com.nexus.module.player;

import com.nexus.module.Category;
import com.nexus.module.Module;
import com.nexus.setting.ModeSetting;
import com.nexus.setting.NumberSetting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

public class AntiAFK extends Module {
    private final NumberSetting interval = add(new NumberSetting("Seconds", 20, 5, 120, 1));
    private final ModeSetting mode = add(new ModeSetting("Mode", "Swing", "Swing", "Jump"));
    private int ticks = 0;

    public AntiAFK() { super("AntiAFK", "AFK görünmemek için periyodik hareket eder", Category.PLAYER); }

    @Override public String getInfo() { return mode.get(); }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        if (++ticks < interval.get().intValue() * 20) return;
        ticks = 0;
        if (mode.is("Swing")) {
            p.swingHand(Hand.MAIN_HAND);
        } else if (p.isOnGround()) {
            Vec3d v = p.getVelocity();
            p.setVelocity(v.x, 0.42, v.z);
        }
    }
}
