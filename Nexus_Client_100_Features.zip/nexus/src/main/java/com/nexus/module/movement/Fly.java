package com.nexus.module.movement;

import com.nexus.module.Category;
import com.nexus.module.Module;
import com.nexus.setting.ModeSetting;
import com.nexus.setting.NumberSetting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

import org.lwjgl.glfw.GLFW;

public class Fly extends Module {
    private final ModeSetting mode = add(new ModeSetting("Mode", "Motion", "Motion", "Abilities"));
    private final NumberSetting speed = add(new NumberSetting("Speed", 1.0, 0.1, 5.0, 0.1));

    public Fly() {
        super("Fly", "Havada uçmanı sağlar", Category.MOVEMENT);
        setKey(GLFW.GLFW_KEY_G);
    }

    @Override public String getInfo() { return mode.get(); }

    @Override
    protected void onDisable() {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        if (!p.isCreative() && !p.isSpectator()) {
            p.getAbilities().flying = false;
            p.getAbilities().allowFlying = false;
        }
        p.getAbilities().setFlySpeed(0.05f);
    }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;

        if (mode.is("Abilities")) {
            p.getAbilities().allowFlying = true;
            p.getAbilities().flying = true;
            p.getAbilities().setFlySpeed(speed.f() * 0.05f);
            return;
        }

        // Motion mode
        double s = speed.get();
        double yaw = Math.toRadians(p.getYaw());
        double fx = -Math.sin(yaw), fz = Math.cos(yaw);   // forward
        double rx = Math.cos(yaw), rz = Math.sin(yaw);    // right... (strafe)

        double mx = 0, mz = 0;
        if (mc.options.forwardKey.isPressed()) { mx += fx; mz += fz; }
        if (mc.options.backKey.isPressed())    { mx -= fx; mz -= fz; }
        if (mc.options.leftKey.isPressed())    { mx -= rx; mz -= rz; }
        if (mc.options.rightKey.isPressed())   { mx += rx; mz += rz; }

        double len = Math.sqrt(mx * mx + mz * mz);
        if (len > 0) { mx = mx / len * s; mz = mz / len * s; }

        double my = 0;
        if (mc.options.jumpKey.isPressed())  my += s;
        if (mc.options.sneakKey.isPressed()) my -= s;

        p.setVelocity(new Vec3d(mx, my, mz));
        p.fallDistance = 0;
    }
}
