package com.nexus.module.world;

import com.nexus.module.Category;
import com.nexus.module.Module;
import com.nexus.setting.NumberSetting;
import com.nexus.util.PlayerUtil;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

/** Etraf karanlıksa hotbar'daki meşaleyi ayağının altına koyar. */
public class AutoTorch extends Module {
    private final NumberSetting level = add(new NumberSetting("LightLevel", 4, 0, 7, 1));
    private int cooldown = 0;

    public AutoTorch() { super("AutoTorch", "Karanlıkta otomatik meşale koyar", Category.WORLD); }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.currentScreen != null) return;
        if (cooldown > 0) { cooldown--; return; }

        BlockPos feet = p.getBlockPos();
        if (mc.world.getLightLevel(feet) > level.get().intValue()) return;
        if (!mc.world.getBlockState(feet).isReplaceable()) return;
        BlockPos below = feet.down();
        if (mc.world.getBlockState(below).isReplaceable()) return;

        int slot = PlayerUtil.hotbarSlot(p, Items.TORCH);
        if (slot < 0) return;
        PlayerUtil.placeAgainst(mc, p, slot, below, Direction.UP);
        cooldown = 20;
    }
}
