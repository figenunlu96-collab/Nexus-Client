package com.nexus.module.combat;

import com.nexus.module.Category;
import com.nexus.module.Module;
import com.nexus.setting.NumberSetting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

/** Sol tık basılıyken ve crosshair bir varlıktayken sabit CPS ile vurur. */
public class AutoClicker extends Module {
    private final NumberSetting cps = add(new NumberSetting("CPS", 10, 1, 20, 1));
    private int ticks = 0;

    public AutoClicker() { super("AutoClicker", "Basılı tutunca otomatik tıklar", Category.COMBAT); }

    @Override public String getInfo() { return String.valueOf(cps.get().intValue()); }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (!mc.options.attackKey.isPressed()) { ticks = 0; return; }
        if (mc.crosshairTarget == null || mc.crosshairTarget.getType() != HitResult.Type.ENTITY) return;

        int interval = Math.max(1, Math.round(20f / cps.f()));
        if (++ticks < interval) return;
        ticks = 0;

        mc.interactionManager.attackEntity(p, ((EntityHitResult) mc.crosshairTarget).getEntity());
        p.swingHand(Hand.MAIN_HAND);
    }
}
