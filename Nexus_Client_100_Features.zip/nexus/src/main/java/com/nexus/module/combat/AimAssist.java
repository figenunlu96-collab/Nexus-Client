package com.nexus.module.combat;

import com.nexus.module.Category;
import com.nexus.module.Module;
import com.nexus.setting.BooleanSetting;
import com.nexus.setting.NumberSetting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Kamerayı en yakın hedefe doğru yumuşakça çevirir. */
public class AimAssist extends Module {
    private final NumberSetting range = add(new NumberSetting("Range", 4.5, 1.0, 8.0, 0.5));
    private final NumberSetting smooth = add(new NumberSetting("Smooth", 4.0, 0.5, 20.0, 0.5));
    private final NumberSetting fov = add(new NumberSetting("FOV", 60, 10, 180, 5));
    private final BooleanSetting onlyPlayers = add(new BooleanSetting("OnlyPlayers", false));

    public AimAssist() { super("AimAssist", "Nişanı hedefe doğru yumuşak çevirir", Category.COMBAT); }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.currentScreen != null) return;

        Entity best = null;
        double bd = range.get();
        for (Entity e : mc.world.getEntities()) {
            if (e == p || !(e instanceof LivingEntity le) || !le.isAlive()) continue;
            boolean ok = e instanceof PlayerEntity || (!onlyPlayers.get() && e instanceof HostileEntity);
            if (!ok) continue;
            double d = p.distanceTo(e);
            if (d <= bd) { best = e; bd = d; }
        }
        if (best == null) return;

        Vec3d eye = p.getEyePos();
        Vec3d t = best.getBoundingBox().getCenter();
        double dx = t.x - eye.x, dy = t.y - eye.y, dz = t.z - eye.z;
        float ty = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float tp = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));

        float dyaw = MathHelper.wrapDegrees(ty - p.getYaw());
        float dpitch = tp - p.getPitch();
        if (Math.abs(dyaw) > fov.get()) return;

        float s = smooth.f();
        p.setYaw(p.getYaw() + MathHelper.clamp(dyaw, -s, s));
        p.setPitch(MathHelper.clamp(p.getPitch() + MathHelper.clamp(dpitch, -s, s), -90f, 90f));
    }
}
