package com.nexus.module.combat;

import com.nexus.module.Category;
import com.nexus.module.Module;
import com.nexus.setting.BooleanSetting;
import com.nexus.setting.NumberSetting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;

/** Menzildeki en yakın hedefe, saldırı yenilenince vurur. Menzil vanilla sınırında tutulur. */
public class KillAura extends Module {
    private final NumberSetting range = add(new NumberSetting("Range", 3.0, 1.0, 4.5, 0.1));
    private final BooleanSetting players = add(new BooleanSetting("Players", true));
    private final BooleanSetting hostiles = add(new BooleanSetting("Hostiles", true));
    private final BooleanSetting animals = add(new BooleanSetting("Animals", false));

    public KillAura() {
        super("KillAura", "Yakındaki hedefe otomatik vurur", Category.COMBAT);
    }

    @Override public String getInfo() { return String.format("%.1f", range.get()); }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (p.getAttackCooldownProgress(0.5f) < 1.0f) return;

        Entity best = null;
        double bestDist = range.get();
        for (Entity e : mc.world.getEntities()) {
            if (e == p || !(e instanceof LivingEntity le) || !le.isAlive()) continue;
            boolean ok = (players.get() && e instanceof PlayerEntity)
                      || (hostiles.get() && e instanceof HostileEntity)
                      || (animals.get() && e instanceof AnimalEntity);
            if (!ok) continue;
            double d = p.distanceTo(e);
            if (d <= bestDist) { best = e; bestDist = d; }
        }
        if (best == null) return;

        mc.interactionManager.attackEntity(p, best);
        p.swingHand(Hand.MAIN_HAND);
    }
}
