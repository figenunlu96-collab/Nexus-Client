package com.nexus.module.combat;

import com.nexus.module.Category;
import com.nexus.module.Module;
import com.nexus.setting.NumberSetting;
import com.nexus.util.PlayerUtil;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

/** Ayağının dört yanına obsidyen koyar (hotbar'da obsidyen olmalı). */
public class Surround extends Module {
    private static final Direction[] SIDES = { Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST };
    private final NumberSetting delay = add(new NumberSetting("Delay", 1, 0, 10, 1));
    private int cooldown = 0;

    public Surround() { super("Surround", "Etrafına obsidyen duvar örer", Category.COMBAT); }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.currentScreen != null) return;
        if (cooldown > 0) { cooldown--; return; }

        int slot = PlayerUtil.hotbarSlot(p, Items.OBSIDIAN);
        if (slot < 0) return;

        BlockPos feet = p.getBlockPos();
        for (Direction d : SIDES) {
            BlockPos t = feet.offset(d);
            if (!mc.world.getBlockState(t).isReplaceable()) continue;
            BlockPos base = t.down();
            if (mc.world.getBlockState(base).isReplaceable()) continue;
            PlayerUtil.placeAgainst(mc, p, slot, base, Direction.UP);
            cooldown = delay.get().intValue();
            return;
        }
    }
}
