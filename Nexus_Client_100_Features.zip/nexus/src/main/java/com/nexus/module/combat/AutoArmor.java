package com.nexus.module.combat;

import com.nexus.module.Category;
import com.nexus.module.Module;
import com.nexus.setting.NumberSetting;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.EquippableComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

/** Boş zırh slotlarına envanterdeki zırhı otomatik giydirir. */
public class AutoArmor extends Module {
    private final NumberSetting delay = add(new NumberSetting("Delay", 3, 0, 20, 1));
    private int cooldown = 0;

    public AutoArmor() {
        super("AutoArmor", "Boş zırh slotlarını otomatik doldurur", Category.COMBAT);
    }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null) return;
        if (cooldown > 0) { cooldown--; return; }
        if (mc.currentScreen != null && !(mc.currentScreen instanceof InventoryScreen)) return;

        for (int i = 0; i < 36; i++) {
            ItemStack st = p.getInventory().getStack(i);
            if (st.isEmpty() || st.isOf(Items.CARVED_PUMPKIN)) continue;
            EquippableComponent eq = st.get(DataComponentTypes.EQUIPPABLE);
            if (eq == null || !eq.slot().isArmorSlot()) continue;
            if (!p.getEquippedStack(eq.slot()).isEmpty()) continue;

            int containerSlot = i < 9 ? 36 + i : i;
            mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, containerSlot, 0, SlotActionType.QUICK_MOVE, p);
            cooldown = delay.get().intValue();
            return;
        }
    }
}
