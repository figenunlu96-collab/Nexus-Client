package com.nexus.module.movement;

import com.nexus.module.Category;
import com.nexus.module.Module;
import com.nexus.setting.NumberSetting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

public class Glide extends Module {
    private final NumberSetting fall = add(new NumberSetting("FallSpeed", 0.1, 0.02, 0.5, 0.01));

    public Glide() { super("Glide", "Yavaş düşürür (paraşüt)", Category.MOVEMENT); }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null || p.isOnGround() || p.isTouchingWater()) return;
        Vec3d v = p.getVelocity();
        if (v.y < -fall.get()) {
            p.setVelocity(v.x, -fall.get(), v.z);
            p.fallDistance = 0;
        }
    }
}
