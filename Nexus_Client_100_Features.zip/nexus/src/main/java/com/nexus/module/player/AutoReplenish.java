package com.nexus.module.player;

import com.nexus.module.Category;
import com.nexus.module.Module;
import com.nexus.setting.NumberSetting;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;

/** Hotbar'daki yığın azalınca envanterden aynı eşyayla tamamlar. */
public class AutoReplenish extends Module {
    private final NumberSetting threshold = add(new NumberSetting("Threshold", 8, 1, 32, 1));
    private int cooldown = 0;

    public AutoReplenish() { super("AutoReplenish", "Hotbar yığınını otomatik doldurur", Category.PLAYER); }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null) return;
        if (cooldown > 0) { cooldown--; return; }
        if (mc.currentScreen != null && !(mc.currentScreen instanceof InventoryScreen)) return;

        int sync = p.playerScreenHandler.syncId;
        for (int i = 0; i < 9; i++) {
            ItemStack hb = p.getInventory().getStack(i);
            if (hb.isEmpty() || !hb.isStackable() || hb.getCount() > threshold.get().intValue()) continue;

            for (int j = 9; j < 36; j++) {
                ItemStack inv = p.getInventory().getStack(j);
                if (inv.isEmpty() || !ItemStack.areItemsAndComponentsEqual(hb, inv)) continue;

                mc.interactionManager.clickSlot(sync, j, 0, SlotActionType.PICKUP, p);
                mc.interactionManager.clickSlot(sync, 36 + i, 0, SlotActionType.PICKUP, p);
                if (!p.playerScreenHandler.getCursorStack().isEmpty()) {
                    mc.interactionManager.clickSlot(sync, j, 0, SlotActionType.PICKUP, p);
                }
                cooldown = 5;
                return;
            }
        }
    }
}
