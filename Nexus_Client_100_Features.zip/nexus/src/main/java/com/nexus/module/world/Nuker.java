package com.nexus.module.world;

import com.nexus.module.Category;
import com.nexus.module.Module;
import com.nexus.setting.NumberSetting;
import net.minecraft.block.BlockState;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Çevrendeki blokları kırar. Yalnızca kendi dünyanda / izinli yerlerde kullan. */
public class Nuker extends Module {
    private final NumberSetting radius = add(new NumberSetting("Radius", 3, 1, 4, 1));

    public Nuker() { super("Nuker", "Yakındaki blokları otomatik kırar", Category.WORLD); }

    @Override public String getInfo() { return String.valueOf(radius.get().intValue()); }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;

        int r = radius.get().intValue();
        BlockPos c = p.getBlockPos();
        List<BlockPos> list = new ArrayList<>();
        for (int x = -r; x <= r; x++)
            for (int y = -r; y <= r; y++)
                for (int z = -r; z <= r; z++) {
                    BlockPos pos = c.add(x, y, z);
                    BlockState st = mc.world.getBlockState(pos);
                    if (st.isAir() || !st.getFluidState().isEmpty()) continue;
                    if (st.getHardness(mc.world, pos) < 0) continue; // bedrock vb.
                    if (p.getEyePos().distanceTo(pos.toCenterPos()) > 4.5) continue;
                    list.add(pos);
                }
        if (list.isEmpty()) return;
        list.sort(Comparator.comparingDouble(b -> p.getEyePos().squaredDistanceTo(b.toCenterPos())));

        if (p.isCreative()) {
            for (int i = 0; i < Math.min(8, list.size()); i++) {
                mc.interactionManager.attackBlock(list.get(i), Direction.UP);
            }
        } else {
            mc.interactionManager.updateBlockBreakingProgress(list.get(0), Direction.UP);
        }
        p.swingHand(Hand.MAIN_HAND);
    }
}
