package com.nexus.module.movement;

import com.nexus.module.Category;
import com.nexus.module.Module;
import com.nexus.setting.NumberSetting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Düşerken daha hızlı iner. Düşme hasarı almamak için NoFall ile birlikte kullan. */
public class FastFall extends Module {
    private final NumberSetting speed = add(new NumberSetting("Speed", 1.0, 0.3, 3.0, 0.1));

    public FastFall() { super("FastFall", "Düşerken hızlandırır", Category.MOVEMENT); }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null || p.isOnGround() || p.isTouchingWater()) return;
        Vec3d v = p.getVelocity();
        if (v.y < 0) p.setVelocity(v.x, Math.max(-3.0, Math.min(v.y, -speed.get())), v.z);
    }
}
