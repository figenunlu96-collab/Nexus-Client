package com.nexus.module.movement;

import com.nexus.module.Category;
import com.nexus.module.Module;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

public class Jesus extends Module {
    public Jesus() { super("Jesus", "Suyun üstünde yürütür", Category.MOVEMENT); }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        if (p.isTouchingWater() && !mc.options.sneakKey.isPressed()) {
            Vec3d v = p.getVelocity();
            p.setVelocity(v.x, 0.11, v.z);
        }
    }
}
