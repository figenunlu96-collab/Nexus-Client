package com.nexus.module.hud;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import org.lwjgl.glfw.GLFW;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayDeque;
import java.util.Deque;

/** Basit metin HUD bileşenleri: FPS, CPS, Ping, XYZ, Speed, Clock. */
public final class Huds {
    private Huds() {}

    public static class Fps extends HudModule {
        public Fps() { super("FPS", "FPS göstergesi", 40); }
        @Override public String text() { return "FPS: " + mc.getCurrentFps(); }
    }

    public static class Cps extends HudModule {
        private final Deque<Long> clicks = new ArrayDeque<>();
        private boolean was = false;

        public Cps() { super("CPS", "Saniyedeki sol tık sayısı", 52); }

        @Override
        public void onTick() {
            if (mc.getWindow() == null) return;
            boolean down = GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
            long now = System.currentTimeMillis();
            if (down && !was) clicks.addLast(now);
            was = down;
            while (!clicks.isEmpty() && now - clicks.peekFirst() > 1000) clicks.pollFirst();
        }

        @Override public String text() { return "CPS: " + clicks.size(); }
    }

    public static class Ping extends HudModule {
        public Ping() { super("Ping", "Gecikme göstergesi", 64); }

        @Override
        public String text() {
            ClientPlayerEntity p = mc.player;
            if (p == null || mc.getNetworkHandler() == null) return "Ping: -";
            PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(p.getUuid());
            return "Ping: " + (e == null ? "-" : e.getLatency() + " ms");
        }
    }

    public static class Coords extends HudModule {
        public Coords() { super("XYZ", "Koordinatlar", 76); }

        @Override
        public String text() {
            ClientPlayerEntity p = mc.player;
            if (p == null) return "";
            return "XYZ: " + p.getBlockX() + " " + p.getBlockY() + " " + p.getBlockZ();
        }
    }

    public static class SpeedHud extends HudModule {
        private double lastX, lastZ, speed;
        private boolean init = false;

        public SpeedHud() { super("SpeedHUD", "Hız (blok/sn)", 88); }

        @Override
        public void onTick() {
            ClientPlayerEntity p = mc.player;
            if (p == null) return;
            if (init) speed = Math.hypot(p.getX() - lastX, p.getZ() - lastZ) * 20.0;
            lastX = p.getX(); lastZ = p.getZ();
            init = true;
        }

        @Override protected void onDisable() { init = false; }
        @Override public String text() { return String.format("Speed: %.2f b/s", speed); }
    }

    public static class Clock extends HudModule {
        private static final DateTimeFormatter F = DateTimeFormatter.ofPattern("HH:mm:ss");
        public Clock() { super("Clock", "Gerçek saat", 100); }
        @Override public String text() { return "Time: " + LocalTime.now().format(F); }
    }
}
