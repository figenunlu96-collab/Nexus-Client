package com.nexus.module.movement;

import com.nexus.module.Category;
import com.nexus.module.Module;
import com.nexus.setting.NumberSetting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

public class Dolphin extends Module {
    private final NumberSetting boost = add(new NumberSetting("Boost", 1.1, 1.0, 1.2, 0.01));

    public Dolphin() { super("Dolphin", "Suda yunus gibi hızlı yüzdürür", Category.MOVEMENT); }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null || !p.isTouchingWater()) return;
        Vec3d v = p.getVelocity();
        double b = boost.get();
        p.setVelocity(v.x * b, v.y, v.z * b);
    }
}
