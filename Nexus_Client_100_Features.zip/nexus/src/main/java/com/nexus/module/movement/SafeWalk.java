package com.nexus.module.movement;

import com.nexus.module.Category;
import com.nexus.module.Module;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

/** Kenara gelince otomatik eğilir, düşmeni engeller. */
public class SafeWalk extends Module {
    private boolean forced = false;

    public SafeWalk() { super("SafeWalk", "Kenarda otomatik eğilir", Category.MOVEMENT); }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null) return;
        boolean edge = false;
        if (p.isOnGround()) {
            Vec3d v = p.getVelocity();
            BlockPos ahead = BlockPos.ofFloored(p.getX() + v.x * 4, p.getY() - 0.5, p.getZ() + v.z * 4);
            edge = mc.world.getBlockState(ahead).isAir();
        }
        if (edge) { mc.options.sneakKey.setPressed(true); forced = true; }
        else if (forced) { mc.options.sneakKey.setPressed(false); forced = false; }
    }

    @Override
    protected void onDisable() {
        if (forced) mc.options.sneakKey.setPressed(false);
        forced = false;
    }
}
