package com.nexus.module.movement;

import com.nexus.module.Category;
import com.nexus.module.Module;
import com.nexus.setting.NumberSetting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

public class FastLadder extends Module {
    private final NumberSetting speed = add(new NumberSetting("Speed", 0.3, 0.1, 0.8, 0.05));

    public FastLadder() { super("FastLadder", "Merdivende hızlı tırmanır", Category.MOVEMENT); }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        if (p.isClimbing() && mc.options.forwardKey.isPressed()) {
            Vec3d v = p.getVelocity();
            p.setVelocity(v.x, speed.get(), v.z);
        }
    }
}
