package com.nexus.module.combat;

import com.nexus.module.Category;
import com.nexus.module.Module;
import com.nexus.setting.BooleanSetting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

/** Crosshair bir canlının üzerindeyken, saldırı yeniden dolunca vurur. */
public class TriggerBot extends Module {
    private final BooleanSetting onlyPlayers = add(new BooleanSetting("OnlyPlayers", false));

    public TriggerBot() {
        super("TriggerBot", "Crosshair hedefteyken otomatik vurur", Category.COMBAT);
    }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (mc.crosshairTarget == null || mc.crosshairTarget.getType() != HitResult.Type.ENTITY) return;

        Entity e = ((EntityHitResult) mc.crosshairTarget).getEntity();
        if (!(e instanceof LivingEntity le) || !le.isAlive()) return;
        if (onlyPlayers.get() && !(e instanceof PlayerEntity)) return;
        if (p.getAttackCooldownProgress(0.5f) < 1.0f) return;

        mc.interactionManager.attackEntity(p, e);
        p.swingHand(Hand.MAIN_HAND);
    }
}
