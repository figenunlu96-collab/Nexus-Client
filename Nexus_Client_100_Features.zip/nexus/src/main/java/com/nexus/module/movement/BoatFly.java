package com.nexus.module.movement;

import com.nexus.module.Category;
import com.nexus.module.Module;
import com.nexus.setting.NumberSetting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;

/** Binekteyken (tekne vb.) zıpla/eğil ile yukarı-aşağı, ileri tuşuyla ileri uçurur. */
public class BoatFly extends Module {
    private final NumberSetting vertical = add(new NumberSetting("Vertical", 0.5, 0.1, 2.0, 0.1));
    private final NumberSetting forward = add(new NumberSetting("Forward", 0.8, 0.0, 3.0, 0.1));

    public BoatFly() { super("BoatFly", "Tekneyle uçmanı sağlar", Category.MOVEMENT); }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        Entity veh = p.getVehicle();
        if (veh == null) return;

        double vy = 0;
        if (mc.options.jumpKey.isPressed()) vy += vertical.get();
        if (mc.options.sneakKey.isPressed()) vy -= vertical.get();

        double mx = 0, mz = 0;
        if (mc.options.forwardKey.isPressed()) {
            double yaw = Math.toRadians(p.getYaw());
            mx = -Math.sin(yaw) * forward.get();
            mz = Math.cos(yaw) * forward.get();
        }
        Vec3d cur = veh.getVelocity();
        veh.setVelocity(mx != 0 || mz != 0 ? mx : cur.x, vy, mx != 0 || mz != 0 ? mz : cur.z);
    }
}
