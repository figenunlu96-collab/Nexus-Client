package com.nexus.module.movement;

import com.nexus.module.Category;
import com.nexus.module.Module;

public class AutoSwim extends Module {
    private boolean forced = false;

    public AutoSwim() { super("AutoSwim", "Suda otomatik yüzer", Category.MOVEMENT); }

    @Override
    public void onTick() {
        if (mc.player == null || mc.currentScreen != null) return;
        if (mc.player.isTouchingWater() && !mc.options.sneakKey.isPressed()) {
            mc.options.jumpKey.setPressed(true); forced = true;
        } else if (forced) {
            mc.options.jumpKey.setPressed(false); forced = false;
        }
    }

    @Override
    protected void onDisable() {
        if (forced) mc.options.jumpKey.setPressed(false);
        forced = false;
    }
}
