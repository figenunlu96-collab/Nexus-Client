package com.nexus.module.player;

import com.nexus.module.Category;
import com.nexus.module.Module;
import net.minecraft.client.gui.screen.DeathScreen;

public class AutoRespawn extends Module {
    public AutoRespawn() { super("AutoRespawn", "Ölünce otomatik yeniden doğar", Category.PLAYER); }

    @Override
    public void onTick() {
        if (mc.player != null && mc.currentScreen instanceof DeathScreen) {
            mc.player.requestRespawn();
        }
    }
}
