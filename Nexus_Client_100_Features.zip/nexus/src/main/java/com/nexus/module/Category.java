package com.nexus.module;

public enum Category { COMBAT, MOVEMENT, PLAYER, RENDER, WORLD, MISC, HUD }
