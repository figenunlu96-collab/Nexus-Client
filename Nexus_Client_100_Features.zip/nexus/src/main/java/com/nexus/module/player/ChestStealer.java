package com.nexus.module.player;

import com.nexus.module.Category;
import com.nexus.module.Module;
import com.nexus.setting.NumberSetting;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;

/** Sandık/varil açıkken içindeki eşyaları sırayla envantere taşır. */
public class ChestStealer extends Module {
    private final NumberSetting delay = add(new NumberSetting("Delay", 2, 0, 20, 1));
    private int cooldown = 0;

    public ChestStealer() { super("ChestStealer", "Açık sandığı otomatik boşaltır", Category.PLAYER); }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null) return;
        if (!(mc.currentScreen instanceof GenericContainerScreen gcs)) return;
        if (cooldown > 0) { cooldown--; return; }

        GenericContainerScreenHandler h = gcs.getScreenHandler();
        int size = h.getRows() * 9;
        for (int i = 0; i < size; i++) {
            if (!h.getSlot(i).getStack().isEmpty()) {
                mc.interactionManager.clickSlot(h.syncId, i, 0, SlotActionType.QUICK_MOVE, p);
                cooldown = delay.get().intValue();
                return;
            }
        }
    }
}
