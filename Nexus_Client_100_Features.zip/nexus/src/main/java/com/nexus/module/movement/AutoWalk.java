package com.nexus.module.movement;

import com.nexus.module.Category;
import com.nexus.module.Module;

public class AutoWalk extends Module {
    public AutoWalk() { super("AutoWalk", "Otomatik ileri yürür", Category.MOVEMENT); }

    @Override
    public void onTick() {
        if (mc.player == null || mc.currentScreen != null) return;
        mc.options.forwardKey.setPressed(true);
    }

    @Override
    protected void onDisable() { mc.options.forwardKey.setPressed(false); }
}
