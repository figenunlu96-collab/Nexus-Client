package com.nexus.module.player;

import com.nexus.module.Category;
import com.nexus.module.Module;
import com.nexus.setting.BooleanSetting;
import com.nexus.setting.NumberSetting;
import net.minecraft.client.network.ClientPlayerEntity;

/** Elindeki eşyayı belirli aralıkla yere atar. */
public class ItemThrower extends Module {
    private final NumberSetting delay = add(new NumberSetting("Delay", 10, 1, 100, 1));
    private final BooleanSetting stack = add(new BooleanSetting("WholeStack", false));
    private int ticks = 0;

    public ItemThrower() { super("ItemThrower", "Eşyayı otomatik fırlatır", Category.PLAYER); }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.currentScreen != null) return;
        if (++ticks < delay.get().intValue()) return;
        ticks = 0;
        if (!p.getMainHandStack().isEmpty()) p.dropSelectedItem(stack.get());
    }
}
