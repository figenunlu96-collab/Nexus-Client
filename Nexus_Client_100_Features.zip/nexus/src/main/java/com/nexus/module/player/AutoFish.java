package com.nexus.module.player;

import com.nexus.module.Category;
import com.nexus.module.Module;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.projectile.FishingBobberEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

/** Olta elindeyken şamandıra batınca oltayı çeker ve tekrar atar. */
public class AutoFish extends Module {
    private int recast = 0;

    public AutoFish() { super("AutoFish", "Otomatik balık tutar", Category.PLAYER); }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (!p.getMainHandStack().isOf(Items.FISHING_ROD)) return;

        if (recast > 0) {
            if (--recast == 0 && p.fishHook == null) use(p);
            return;
        }

        FishingBobberEntity hook = p.fishHook;
        if (hook == null) return;
        if (hook.age > 30 && hook.isTouchingWater() && hook.getVelocity().y < -0.12) {
            use(p);        // çek
            recast = 20;   // 1 sn sonra tekrar at
        }
    }

    private void use(ClientPlayerEntity p) {
        mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
        p.swingHand(Hand.MAIN_HAND);
    }
}
