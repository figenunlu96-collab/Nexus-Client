package com.nexus.module.hud;

import com.nexus.module.Category;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;

import java.util.function.Function;

/** Individual, configurable read-only HUD widget. */
public final class TelemetryHud extends HudModule {
    private final Function<ClientPlayerEntity, String> supplier;

    public TelemetryHud(String name, String description, int y,
                        Function<ClientPlayerEntity, String> supplier) {
        super(name, description, y);
        this.supplier = supplier;
    }

    @Override
    public String text() {
        if (mc.player == null) return "";
        try {
            return supplier.apply(mc.player);
        } catch (RuntimeException ignored) {
            return name + ": -";
        }
    }
}
