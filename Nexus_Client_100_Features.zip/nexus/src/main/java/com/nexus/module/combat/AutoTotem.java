package com.nexus.module.combat;

import com.nexus.module.Category;
import com.nexus.module.Module;
import com.nexus.setting.ModeSetting;
import com.nexus.setting.NumberSetting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

/** Offhand'de her zaman totem tutar. Stok sayısı HUD'da gösterilir. */
public class AutoTotem extends Module {
    public static int totemCount = 0;

    private final NumberSetting delay = add(new NumberSetting("Delay", 2, 0, 20, 1));
    private final NumberSetting health = add(new NumberSetting("Health", 36, 1, 36, 1));
    private final ModeSetting prefer = add(new ModeSetting("Prefer", "Hotbar", "Hotbar", "Inventory"));

    private int cooldown = 0;

    public AutoTotem() {
        super("AutoTotem", "Offhand'e otomatik totem koyar", Category.COMBAT);
    }

    @Override public String getInfo() { return String.valueOf(totemCount); }

    @Override
    protected void onDisable() { totemCount = 0; }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null) return;

        totemCount = countTotems(p);

        if (cooldown > 0) { cooldown--; return; }
        if (p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;
        if (p.getHealth() + p.getAbsorptionAmount() > health.get()) return;
        // başka bir konteyner (sandık vb.) açıksa dokunma
        if (mc.currentScreen != null && !(mc.currentScreen instanceof net.minecraft.client.gui.screen.ingame.InventoryScreen)) return;

        int slot = findTotemSlot(p);
        if (slot < 0) return;

        // button 40 = offhand ile takas
        mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, slot, 40, SlotActionType.SWAP, p);
        cooldown = delay.get().intValue();
    }

    private int countTotems(ClientPlayerEntity p) {
        int n = 0;
        for (int i = 0; i < 36; i++) {
            var st = p.getInventory().getStack(i);
            if (st.isOf(Items.TOTEM_OF_UNDYING)) n += st.getCount();
        }
        if (p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) n += p.getOffHandStack().getCount();
        return n;
    }

    /** Konteyner slot numarası döndürür (player handler: hotbar 36-44, ana envanter 9-35). */
    private int findTotemSlot(ClientPlayerEntity p) {
        boolean hotbarFirst = prefer.is("Hotbar");
        int found = scan(p, hotbarFirst ? 0 : 9, hotbarFirst ? 9 : 36);
        if (found >= 0) return found;
        return scan(p, hotbarFirst ? 9 : 0, hotbarFirst ? 36 : 9);
    }

    private int scan(ClientPlayerEntity p, int from, int to) {
        for (int i = from; i < to; i++) {
            if (p.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) {
                return i < 9 ? 36 + i : i;
            }
        }
        return -1;
    }
}
