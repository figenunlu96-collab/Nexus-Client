package com.nexus.module.movement;

import com.nexus.module.Category;
import com.nexus.module.Module;
import com.nexus.setting.NumberSetting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

public class LongJump extends Module {
    private final NumberSetting boost = add(new NumberSetting("Boost", 1.8, 1.0, 4.0, 0.1));
    private boolean wasOnGround = true;

    public LongJump() { super("LongJump", "Zıplayınca ileri doğru atar", Category.MOVEMENT); }

    @Override public String getInfo() { return String.format("%.1f", boost.get()); }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        if (wasOnGround && !p.isOnGround() && mc.options.jumpKey.isPressed()) {
            Vec3d v = p.getVelocity();
            double b = boost.get();
            p.setVelocity(v.x * b, v.y, v.z * b);
        }
        wasOnGround = p.isOnGround();
    }
}
