package com.nexus.module.hud;

import com.nexus.setting.NumberSetting;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.EntityHitResult;

/** Özel çizim yapan ve sayaç tarzı HUD bileşenleri. */
public final class Overlays {
    private Overlays() {}

    private static int countItem(ClientPlayerEntity p, Item... items) {
        int n = 0;
        for (int i = 0; i < 36; i++) {
            ItemStack s = p.getInventory().getStack(i);
            for (Item it : items) if (s.isOf(it)) n += s.getCount();
        }
        ItemStack off = p.getOffHandStack();
        for (Item it : items) if (off.isOf(it)) n += off.getCount();
        return n;
    }

    // ---------- sayaçlar ----------
    public static class TotemCounter extends HudModule {
        public TotemCounter() { super("TotemCounter", "Envanterdeki totem sayısı", 112); }
        @Override public String text() { return mc.player == null ? "" : "Totems: " + countItem(mc.player, Items.TOTEM_OF_UNDYING); }
    }

    public static class CrystalCounter extends HudModule {
        public CrystalCounter() { super("CrystalCounter", "Envanterdeki end crystal sayısı", 124); }
        @Override public String text() { return mc.player == null ? "" : "Crystals: " + countItem(mc.player, Items.END_CRYSTAL); }
    }

    public static class PotionCounter extends HudModule {
        public PotionCounter() { super("PotionCounter", "Envanterdeki iksir sayısı", 136); }
        @Override public String text() {
            return mc.player == null ? "" : "Potions: " + countItem(mc.player, Items.POTION, Items.SPLASH_POTION);
        }
    }

    public static class EntityCounter extends HudModule {
        public EntityCounter() { super("EntityCounter", "Yüklü varlık sayısı", 148); }
        @Override public String text() {
            if (mc.world == null) return "";
            int n = 0;
            for (Entity ignored : mc.world.getEntities()) n++;
            return "Entities: " + n;
        }
    }

    public static class PlayerCounter extends HudModule {
        public PlayerCounter() { super("PlayerCounter", "Dünyadaki oyuncu sayısı", 160); }
        @Override public String text() { return mc.world == null ? "" : "Players: " + mc.world.getPlayers().size(); }
    }

    public static class Session extends HudModule {
        private static final long START = System.currentTimeMillis();
        public Session() { super("Session", "Oyun süresi", 172); }
        @Override public String text() {
            long s = (System.currentTimeMillis() - START) / 1000;
            return String.format("Session: %dh %02dm %02ds", s / 3600, (s / 60) % 60, s % 60);
        }
    }

    public static class WorldTime extends HudModule {
        public WorldTime() { super("WorldTime", "Oyun içi saat", 184); }
        @Override public String text() {
            if (mc.world == null) return "";
            long t = mc.world.getTimeOfDay() % 24000L;
            int hour = (int) ((t / 1000 + 6) % 24);
            int min = (int) ((t % 1000) * 60 / 1000);
            return String.format("World: %02d:%02d", hour, min);
        }
    }

    public static class ServerInfoHud extends HudModule {
        public ServerInfoHud() { super("ServerInfo", "Sunucu adresi", 196); }
        @Override public String text() {
            if (mc.getCurrentServerEntry() == null) return "Server: Singleplayer";
            return "Server: " + mc.getCurrentServerEntry().address;
        }
    }

    public static class FallDistanceHud extends HudModule {
        public FallDistanceHud() { super("FallDistance", "Düşüş mesafesi", 208); }
        @Override public String text() { return mc.player == null ? "" : String.format("Fall: %.1f", (double) mc.player.fallDistance); }
    }

    // ---------- özel çizimler ----------
    public static class ArmorHud extends HudModule {
        private static final EquipmentSlot[] SLOTS = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET };

        public ArmorHud() { super("ArmorHUD", "Zırh ve dayanıklılık", 230); }

        @Override
        public void render(DrawContext ctx, TextRenderer tr) {
            ClientPlayerEntity p = mc.player;
            if (p == null) return;
            int bx = x.get().intValue(), by = y.get().intValue();
            for (int i = 0; i < SLOTS.length; i++) {
                ItemStack s = p.getEquippedStack(SLOTS[i]);
                if (s.isEmpty()) continue;
                int yy = by + i * 18;
                ctx.drawItem(s, bx, yy);
                if (s.isDamageable()) {
                    int max = s.getMaxDamage();
                    int pct = (max - s.getDamage()) * 100 / Math.max(1, max);
                    int col = pct > 60 ? 0xFF55FF77 : pct > 30 ? 0xFFFFCC33 : 0xFFFF4466;
                    ctx.drawTextWithShadow(tr, pct + "%", bx + 20, yy + 4, col);
                }
            }
        }
    }

    public static class PotionHud extends HudModule {
        public PotionHud() { super("PotionHUD", "Aktif efektler", 310); }

        @Override
        public void render(DrawContext ctx, TextRenderer tr) {
            ClientPlayerEntity p = mc.player;
            if (p == null) return;
            int bx = x.get().intValue(), by = y.get().intValue();
            int i = 0;
            for (StatusEffectInstance e : p.getStatusEffects()) {
                String name = e.getEffectType().value().getName().getString() + " " + (e.getAmplifier() + 1);
                String time;
                if (e.isInfinite()) time = "inf";
                else { int s = e.getDuration() / 20; time = String.format("%d:%02d", s / 60, s % 60); }
                int col = (!e.isInfinite() && e.getDuration() < 200) ? 0xFFFF4466 : argb();
                ctx.drawTextWithShadow(tr, name + "  " + time, bx, by + i * 11, col);
                i++;
            }
        }
    }

    public static class TargetHud extends HudModule {
        private LivingEntity target;
        private int hold = 0;

        public TargetHud() { super("TargetHUD", "Baktığın hedefin canı", 340); }

        @Override
        public void onTick() {
            if (mc.crosshairTarget instanceof EntityHitResult r
                    && r.getEntity() instanceof LivingEntity le && le.isAlive()) {
                target = le; hold = 60;
            } else if (hold > 0) hold--;
            else target = null;
        }

        @Override
        public void render(DrawContext ctx, TextRenderer tr) {
            if (target == null || !target.isAlive()) return;
            int bx = x.get().intValue(), by = y.get().intValue();
            float hp = target.getHealth(), max = Math.max(1f, target.getMaxHealth());
            float frac = Math.max(0f, Math.min(1f, hp / max));
            int col = frac > 0.6f ? 0xFF55FF77 : frac > 0.3f ? 0xFFFFCC33 : 0xFFFF4466;

            ctx.fill(bx, by, bx + 124, by + 32, 0xCC0B0B0F);
            ctx.fill(bx, by, bx + 2, by + 32, 0xFFB44CFF);
            ctx.drawTextWithShadow(tr, target.getName().getString(), bx + 6, by + 4, 0xFFFFFFFF);
            ctx.fill(bx + 6, by + 18, bx + 118, by + 23, 0xFF222230);
            ctx.fill(bx + 6, by + 18, bx + 6 + (int) (112 * frac), by + 23, col);
            ctx.drawTextWithShadow(tr, String.format("%.1f / %.1f", hp, max), bx + 6, by + 24, 0xFFC8C8D8);
        }
    }

    public static class Keystrokes extends HudModule {
        public Keystrokes() { super("Keystrokes", "WASD tuş göstergesi", 380); }

        private void key(DrawContext ctx, TextRenderer tr, int kx, int ky, String label, boolean down) {
            ctx.fill(kx, ky, kx + 16, ky + 16, down ? 0xEEB44CFF : 0xAA0B0B0F);
            ctx.drawTextWithShadow(tr, label, kx + 8 - tr.getWidth(label) / 2, ky + 4, 0xFFFFFFFF);
        }

        @Override
        public void render(DrawContext ctx, TextRenderer tr) {
            if (mc.player == null) return;
            int bx = x.get().intValue(), by = y.get().intValue();
            key(ctx, tr, bx + 18, by,      "W", mc.options.forwardKey.isPressed());
            key(ctx, tr, bx,      by + 18, "A", mc.options.leftKey.isPressed());
            key(ctx, tr, bx + 18, by + 18, "S", mc.options.backKey.isPressed());
            key(ctx, tr, bx + 36, by + 18, "D", mc.options.rightKey.isPressed());
        }
    }

    public static class CooldownBar extends HudModule {
        public CooldownBar() { super("Cooldown", "Saldırı yenilenme çubuğu", 410); }

        @Override
        public void render(DrawContext ctx, TextRenderer tr) {
            ClientPlayerEntity p = mc.player;
            if (p == null) return;
            int bx = x.get().intValue(), by = y.get().intValue();
            float f = Math.max(0f, Math.min(1f, p.getAttackCooldownProgress(0f)));
            ctx.drawTextWithShadow(tr, "Cooldown", bx, by, argb());
            ctx.fill(bx, by + 11, bx + 70, by + 15, 0xFF222230);
            ctx.fill(bx, by + 11, bx + (int) (70 * f), by + 15, f >= 1f ? 0xFF55FF77 : 0xFFB44CFF);
        }
    }

    public static class CustomCrosshair extends HudModule {
        private final NumberSetting size = add(new NumberSetting("Size", 5, 1, 20, 1));
        private final NumberSetting gap = add(new NumberSetting("Gap", 3, 0, 15, 1));

        public CustomCrosshair() { super("CustomCrosshair", "Özel nişangah", 0); }

        @Override
        public void render(DrawContext ctx, TextRenderer tr) {
            int cx = ctx.getScaledWindowWidth() / 2, cy = ctx.getScaledWindowHeight() / 2;
            int s = size.get().intValue(), g = gap.get().intValue(), c = argb();
            ctx.fill(cx - g - s, cy, cx - g, cy + 1, c);
            ctx.fill(cx + g + 1, cy, cx + g + 1 + s, cy + 1, c);
            ctx.fill(cx, cy - g - s, cx + 1, cy - g, c);
            ctx.fill(cx, cy + g + 1, cx + 1, cy + g + 1 + s, c);
        }
    }
}
