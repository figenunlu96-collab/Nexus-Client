package com.nexus.module.render;

import com.nexus.module.Category;
import com.nexus.module.Module;
import com.nexus.setting.NumberSetting;

public class FovChanger extends Module {
    private final NumberSetting fov = add(new NumberSetting("FOV", 100, 30, 150, 1));
    private int old = 70;

    public FovChanger() { super("FovChanger", "Görüş açısını (FOV) değiştirir", Category.RENDER); }

    @Override protected void onEnable() { old = mc.options.getFov().getValue(); }

    @Override
    public void onTick() { mc.options.getFov().setValue(fov.get().intValue()); }

    @Override
    protected void onDisable() { mc.options.getFov().setValue(old); }
}
