package com.nexus.module.combat;

import com.nexus.module.Category;
import com.nexus.module.Module;
import com.nexus.setting.NumberSetting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;

/** Elinde kalkan varken yakında düşman olunca kalkanı kaldırır. */
public class AutoBlock extends Module {
    private final NumberSetting range = add(new NumberSetting("Range", 4.0, 2.0, 8.0, 0.5));
    private boolean active = false;

    public AutoBlock() { super("AutoBlock", "Düşman yaklaşınca kalkan kaldırır", Category.COMBAT); }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.currentScreen != null) return;

        boolean shield = p.getOffHandStack().isOf(Items.SHIELD) || p.getMainHandStack().isOf(Items.SHIELD);
        boolean near = false;
        if (shield) {
            for (Entity e : mc.world.getEntities()) {
                if (e == p || !(e instanceof LivingEntity le) || !le.isAlive()) continue;
                if (!(e instanceof PlayerEntity || e instanceof HostileEntity)) continue;
                if (p.distanceTo(e) <= range.get()) { near = true; break; }
            }
        }
        if (near) { mc.options.useKey.setPressed(true); active = true; }
        else if (active) { mc.options.useKey.setPressed(false); active = false; }
    }

    @Override
    protected void onDisable() {
        if (active) mc.options.useKey.setPressed(false);
        active = false;
    }
}
