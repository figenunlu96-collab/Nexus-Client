package com.nexus.module;

import com.nexus.setting.Setting;
import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    protected static final MinecraftClient mc = MinecraftClient.getInstance();

    public final String name;
    public final String description;
    public final Category category;
    private boolean enabled;
    private int key = -1; // GLFW key code, -1 = none
    private final List<Setting<?>> settings = new ArrayList<>();

    protected Module(String name, String description, Category category) {
        this.name = name;
        this.description = description;
        this.category = category;
    }

    protected <S extends Setting<?>> S add(S s) { settings.add(s); return s; }

    public List<Setting<?>> getSettings() { return settings; }

    public boolean isEnabled() { return enabled; }
    public int getKey() { return key; }
    public void setKey(int key) { this.key = key; }

    public void setEnabled(boolean on) {
        if (on == enabled) return;
        enabled = on;
        if (on) onEnable(); else onDisable();
    }

    public void toggle() { setEnabled(!enabled); }

    /** Suffix shown next to the name in the ArrayList (e.g. mode). */
    public String getInfo() { return ""; }

    protected void onEnable() {}
    protected void onDisable() {}
    public void onTick() {}
}
