package com.nexus.module.combat;

import com.nexus.module.Category;
import com.nexus.module.Module;
import com.nexus.setting.ModeSetting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.hit.HitResult;

/** Bir varlığa saldırırken hotbar'daki kılıcı/baltayı seçer. */
public class AutoWeapon extends Module {
    private final ModeSetting prefer = add(new ModeSetting("Prefer", "Sword", "Sword", "Axe"));

    public AutoWeapon() { super("AutoWeapon", "Saldırırken silaha geçer", Category.COMBAT); }

    @Override public String getInfo() { return prefer.get(); }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.currentScreen != null) return;
        if (!mc.options.attackKey.isPressed()) return;
        if (mc.crosshairTarget == null || mc.crosshairTarget.getType() != HitResult.Type.ENTITY) return;

        boolean sword = prefer.is("Sword");
        int slot = find(p, sword);
        if (slot < 0) slot = find(p, !sword);
        if (slot >= 0 && slot != p.getInventory().getSelectedSlot()) p.getInventory().setSelectedSlot(slot);
    }

    private int find(ClientPlayerEntity p, boolean sword) {
        for (int i = 0; i < 9; i++) {
            ItemStack s = p.getInventory().getStack(i);
            if (s.isIn(sword ? ItemTags.SWORDS : ItemTags.AXES)) return i;
        }
        return -1;
    }
}
