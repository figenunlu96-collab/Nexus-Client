package com.nexus.module.movement;

import com.nexus.module.Category;
import com.nexus.module.Module;
import com.nexus.setting.NumberSetting;
import com.nexus.util.PlayerUtil;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

public class Bhop extends Module {
    private final NumberSetting boost = add(new NumberSetting("Boost", 1.15, 1.0, 1.6, 0.01));

    public Bhop() { super("Bhop", "Zıplayarak hızlanır", Category.MOVEMENT); }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.currentScreen != null) return;
        if (p.isOnGround() && PlayerUtil.moving(mc) && !p.isSneaking()) {
            Vec3d v = p.getVelocity();
            double b = boost.get();
            p.setVelocity(v.x * b, 0.42, v.z * b);
        }
    }
}
