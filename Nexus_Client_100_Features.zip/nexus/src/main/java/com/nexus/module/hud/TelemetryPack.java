package com.nexus.module.hud;

import com.nexus.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.List;

/**
 * 100 ayrı, açılıp kapatılabilir ve konumlandırılabilir HUD göstergesi.
 * Bunlar salt-okunur istemci göstergeleridir; sunucuya paket/komut göndermez.
 */
public final class TelemetryPack {
    private TelemetryPack() {}

    private static MinecraftClient mc() { return MinecraftClient.getInstance(); }
    private static String f(double value) { return String.format(java.util.Locale.ROOT, "%.2f", value); }
    private static String yn(boolean value) { return value ? "Yes" : "No"; }
    private static String item(ClientPlayerEntity p, int slot) {
        ItemStack stack = p.getInventory().getStack(slot);
        return stack.isEmpty() ? "Empty" : stack.getName().getString();
    }
    private static int empty(ClientPlayerEntity p) {
        int count = 0;
        for (int i = 0; i < 36; i++) if (p.getInventory().getStack(i).isEmpty()) count++;
        return count;
    }
    private static String block(ClientPlayerEntity p, int offset) {
        if (mc().world == null) return "-";
        BlockPos pos = p.getBlockPos().add(0, offset, 0);
        return mc().world.getBlockState(pos).getBlock().getName().getString();
    }
    private static int ping(ClientPlayerEntity p) {
        if (mc().getNetworkHandler() == null) return -1;
        PlayerListEntry entry = mc().getNetworkHandler().getPlayerListEntry(p.getUuid());
        return entry == null ? -1 : entry.getLatency();
    }
    private static String durability(ItemStack stack) {
        if (!stack.isDamageable()) return "N/A";
        int max = stack.getMaxDamage();
        return max <= 0 ? "N/A" : f((max - stack.getDamage()) * 100.0 / max) + "%";
    }
    private static String direction(float yaw) {
        float angle = (yaw % 360 + 360) % 360;
        if (angle >= 315 || angle < 45) return "South";
        if (angle < 135) return "West";
        if (angle < 225) return "North";
        return "East";
    }
    private static String phase(long time) {
        if (time < 1000 || time >= 23000) return "Sunrise";
        if (time < 12000) return "Day";
        if (time < 13000) return "Sunset";
        return "Night";
    }

    public static List<Module> create() {
        List<Module> out = new ArrayList<>(100);
        out.add(new TelemetryHud("Health", "Health göstergesi", 40, p -> "Health: " + f(p.getHealth())));
        out.add(new TelemetryHud("HealthPercent", "Health percentage göstergesi", 50, p -> "Health: " + f(p.getHealth() * 100.0 / Math.max(1, p.getMaxHealth())) + "%"));
        out.add(new TelemetryHud("MaxHealth", "MaxHealth göstergesi", 60, p -> "Max HP: " + f(p.getMaxHealth())));
        out.add(new TelemetryHud("Absorption", "Absorption göstergesi", 70, p -> "Absorb: " + f(p.getAbsorptionAmount())));
        out.add(new TelemetryHud("Hunger", "Hunger göstergesi", 80, p -> "Hunger: " + p.getHungerManager().getFoodLevel()));
        out.add(new TelemetryHud("Saturation", "Saturation göstergesi", 90, p -> "Saturation: " + f(p.getHungerManager().getSaturationLevel())));
        out.add(new TelemetryHud("Air", "Air göstergesi", 100, p -> "Air: " + p.getAir()));
        out.add(new TelemetryHud("Armor", "Armor göstergesi", 110, p -> "Armor: " + p.getArmor()));
        out.add(new TelemetryHud("XPLevel", "XPLevel göstergesi", 120, p -> "XP Level: " + p.experienceLevel));
        out.add(new TelemetryHud("XPProgress", "XPProgress göstergesi", 130, p -> "XP: " + f(p.experienceProgress * 100) + "%"));
        out.add(new TelemetryHud("PosX", " position X göstergesi", 140, p -> "X: " + f(p.getX())));
        out.add(new TelemetryHud("PosY", " position Y göstergesi", 150, p -> "Y: " + f(p.getY())));
        out.add(new TelemetryHud("PosZ", " position Z göstergesi", 160, p -> "Z: " + f(p.getZ())));
        out.add(new TelemetryHud("BlockX", "BlockX göstergesi", 170, p -> "Block X: " + p.getBlockX()));
        out.add(new TelemetryHud("BlockY", "BlockY göstergesi", 180, p -> "Block Y: " + p.getBlockY()));
        out.add(new TelemetryHud("BlockZ", "BlockZ göstergesi", 190, p -> "Block Z: " + p.getBlockZ()));
        out.add(new TelemetryHud("ChunkX", "ChunkX göstergesi", 200, p -> "Chunk X: " + (p.getBlockX() >> 4)));
        out.add(new TelemetryHud("ChunkZ", "ChunkZ göstergesi", 210, p -> "Chunk Z: " + (p.getBlockZ() >> 4)));
        out.add(new TelemetryHud("Yaw", "Yaw göstergesi", 220, p -> "Yaw: " + f(p.getYaw())));
        out.add(new TelemetryHud("Pitch", "Pitch göstergesi", 230, p -> "Pitch: " + f(p.getPitch())));
        out.add(new TelemetryHud("VelocityX", "VelocityX göstergesi", 240, p -> "Vel X: " + f(p.getVelocity().x)));
        out.add(new TelemetryHud("VelocityY", "VelocityY göstergesi", 250, p -> "Vel Y: " + f(p.getVelocity().y)));
        out.add(new TelemetryHud("VelocityZ", "VelocityZ göstergesi", 260, p -> "Vel Z: " + f(p.getVelocity().z)));
        out.add(new TelemetryHud("HorizontalSpeed", "HorizontalSpeed göstergesi", 270, p -> "H-Speed: " + f(Math.hypot(p.getVelocity().x, p.getVelocity().z) * 20)));
        out.add(new TelemetryHud("VerticalSpeed", "VerticalSpeed göstergesi", 280, p -> "V-Speed: " + f(p.getVelocity().y * 20)));
        out.add(new TelemetryHud("MotionLength", "MotionLength göstergesi", 290, p -> "Motion: " + f(p.getVelocity().length())));
        out.add(new TelemetryHud("OnGround", "OnGround göstergesi", 300, p -> "Ground: " + yn(p.isOnGround())));
        out.add(new TelemetryHud("Sprinting", "Sprinting göstergesi", 310, p -> "Sprint: " + yn(p.isSprinting())));
        out.add(new TelemetryHud("Sneaking", "Sneaking göstergesi", 320, p -> "Sneak: " + yn(p.isSneaking())));
        out.add(new TelemetryHud("Swimming", "Swimming göstergesi", 330, p -> "Swim: " + yn(p.isSwimming())));
        out.add(new TelemetryHud("TouchingWater", "TouchingWater göstergesi", 340, p -> "Water: " + yn(p.isTouchingWater())));
        out.add(new TelemetryHud("InLava", "InLava göstergesi", 350, p -> "Lava: " + yn(p.isInLava())));
        out.add(new TelemetryHud("FallFlying", "FallFlying göstergesi", 360, p -> "Elytra: " + yn(p.isFallFlying())));
        out.add(new TelemetryHud("OnFire", "OnFire göstergesi", 370, p -> "Fire: " + yn(p.isOnFire())));
        out.add(new TelemetryHud("Frozen", "Frozen göstergesi", 380, p -> "Frozen: " + yn(p.isFrozen())));
        out.add(new TelemetryHud("FallDistance", "FallDistance göstergesi", 390, p -> "Fall: " + f(p.fallDistance)));
        out.add(new TelemetryHud("SelectedSlot", "SelectedSlot göstergesi", 400, p -> "Slot: " + (p.getInventory().getSelectedSlot() + 1)));
        out.add(new TelemetryHud("MainHand", "MainHand göstergesi", 410, p -> "Hand: " + p.getMainHandStack().getName().getString()));
        out.add(new TelemetryHud("MainCount", "MainCount göstergesi", 420, p -> "Hand Count: " + p.getMainHandStack().getCount()));
        out.add(new TelemetryHud("OffHand", "OffHand göstergesi", 430, p -> "Offhand: " + p.getOffHandStack().getName().getString()));
        out.add(new TelemetryHud("OffCount", "OffCount göstergesi", 440, p -> "Off Count: " + p.getOffHandStack().getCount()));
        out.add(new TelemetryHud("Hotbar1", "hotbar 1 göstergesi", 450, p -> "Slot 1: " + item(p, 0)));
        out.add(new TelemetryHud("Hotbar2", "hotbar 2 göstergesi", 460, p -> "Slot 2: " + item(p, 1)));
        out.add(new TelemetryHud("Hotbar3", "hotbar 3 göstergesi", 470, p -> "Slot 3: " + item(p, 2)));
        out.add(new TelemetryHud("Hotbar4", "hotbar 4 göstergesi", 480, p -> "Slot 4: " + item(p, 3)));
        out.add(new TelemetryHud("Hotbar5", "hotbar 5 göstergesi", 490, p -> "Slot 5: " + item(p, 4)));
        out.add(new TelemetryHud("Hotbar6", "hotbar 6 göstergesi", 500, p -> "Slot 6: " + item(p, 5)));
        out.add(new TelemetryHud("Hotbar7", "hotbar 7 göstergesi", 510, p -> "Slot 7: " + item(p, 6)));
        out.add(new TelemetryHud("Hotbar8", "hotbar 8 göstergesi", 520, p -> "Slot 8: " + item(p, 7)));
        out.add(new TelemetryHud("Hotbar9", "hotbar 9 göstergesi", 530, p -> "Slot 9: " + item(p, 8)));
        out.add(new TelemetryHud("Hotbar1Count", "hotbar 1Count göstergesi", 540, p -> "Slot 1 #: " + p.getInventory().getStack(0).getCount()));
        out.add(new TelemetryHud("Hotbar2Count", "hotbar 2Count göstergesi", 550, p -> "Slot 2 #: " + p.getInventory().getStack(1).getCount()));
        out.add(new TelemetryHud("Hotbar3Count", "hotbar 3Count göstergesi", 560, p -> "Slot 3 #: " + p.getInventory().getStack(2).getCount()));
        out.add(new TelemetryHud("Hotbar4Count", "hotbar 4Count göstergesi", 570, p -> "Slot 4 #: " + p.getInventory().getStack(3).getCount()));
        out.add(new TelemetryHud("Hotbar5Count", "hotbar 5Count göstergesi", 580, p -> "Slot 5 #: " + p.getInventory().getStack(4).getCount()));
        out.add(new TelemetryHud("Hotbar6Count", "hotbar 6Count göstergesi", 590, p -> "Slot 6 #: " + p.getInventory().getStack(5).getCount()));
        out.add(new TelemetryHud("Hotbar7Count", "hotbar 7Count göstergesi", 600, p -> "Slot 7 #: " + p.getInventory().getStack(6).getCount()));
        out.add(new TelemetryHud("Hotbar8Count", "hotbar 8Count göstergesi", 610, p -> "Slot 8 #: " + p.getInventory().getStack(7).getCount()));
        out.add(new TelemetryHud("Hotbar9Count", "hotbar 9Count göstergesi", 620, p -> "Slot 9 #: " + p.getInventory().getStack(8).getCount()));
        out.add(new TelemetryHud("EmptySlots", "EmptySlots göstergesi", 630, p -> "Empty Slots: " + empty(p)));
        out.add(new TelemetryHud("UsedSlots", "UsedSlots göstergesi", 640, p -> "Used Slots: " + (36 - empty(p))));
        out.add(new TelemetryHud("InventoryPercent", "Inventory percentage göstergesi", 650, p -> "Inventory: " + f((36 - empty(p)) * 100.0 / 36) + "%"));
        out.add(new TelemetryHud("HealthState", "HealthState göstergesi", 660, p -> "Health State: " + (p.getHealth() <= 6 ? "Critical" : p.getHealth() <= 12 ? "Low" : "Healthy")));
        out.add(new TelemetryHud("HungerState", "HungerState göstergesi", 670, p -> "Hunger State: " + (p.getHungerManager().getFoodLevel() <= 6 ? "Hungry" : p.getHungerManager().getFoodLevel() <= 14 ? "Peckish" : "Full")));
        out.add(new TelemetryHud("ArmorState", "ArmorState göstergesi", 680, p -> "Armor State: " + (p.getArmor() >= 20 ? "Max" : p.getArmor() >= 10 ? "Medium" : "Low")));
        out.add(new TelemetryHud("Coordinates", "Coordinates göstergesi", 690, p -> "XYZ: " + p.getBlockX() + ", " + p.getBlockY() + ", " + p.getBlockZ()));
        out.add(new TelemetryHud("WorldTime", "world Time göstergesi", 700, p -> "World Time: " + (mc().world == null ? "-" : mc().world.getTimeOfDay() % 24000)));
        out.add(new TelemetryHud("WorldDay", "world Day göstergesi", 710, p -> "World Day: " + (mc().world == null ? "-" : mc().world.getTimeOfDay() / 24000)));
        out.add(new TelemetryHud("Raining", "Raining göstergesi", 720, p -> "Rain: " + yn(mc().world != null && mc().world.isRaining())));
        out.add(new TelemetryHud("Thundering", "Thundering göstergesi", 730, p -> "Thunder: " + yn(mc().world != null && mc().world.isThundering())));
        out.add(new TelemetryHud("LightLevel", "LightLevel göstergesi", 740, p -> "Light: " + (mc().world == null ? "-" : mc().world.getLightLevel(p.getBlockPos()))));
        out.add(new TelemetryHud("BlockFeet", "BlockFeet göstergesi", 750, p -> "Feet: " + block(p, 0)));
        out.add(new TelemetryHud("BlockBelow", "BlockBelow göstergesi", 760, p -> "Below: " + block(p, -1)));
        out.add(new TelemetryHud("BlockAbove", "BlockAbove göstergesi", 770, p -> "Above: " + block(p, 1)));
        out.add(new TelemetryHud("FPS", "FPS göstergesi", 780, p -> "FPS: " + mc().getCurrentFps()));
        out.add(new TelemetryHud("ScreenWidth", "ScreenWidth göstergesi", 790, p -> "Screen W: " + (mc().getWindow() == null ? 0 : mc().getWindow().getScaledWidth())));
        out.add(new TelemetryHud("ScreenHeight", "ScreenHeight göstergesi", 800, p -> "Screen H: " + (mc().getWindow() == null ? 0 : mc().getWindow().getScaledHeight())));
        out.add(new TelemetryHud("Ping", "Ping göstergesi", 810, p -> "Ping: " + ping(p)));
        out.add(new TelemetryHud("TicksAlive", "TicksAlive göstergesi", 820, p -> "Ticks: " + p.age));
        out.add(new TelemetryHud("HealthPlusAbsorb", "HealthPlusAbsorb göstergesi", 830, p -> "HP Total: " + f(p.getHealth() + p.getAbsorptionAmount())));
        out.add(new TelemetryHud("FoodAndHealth", "FoodAndHealth göstergesi", 840, p -> "Food/HP: " + p.getHungerManager().getFoodLevel() + "/" + f(p.getHealth())));
        out.add(new TelemetryHud("MoveState", "MoveState göstergesi", 850, p -> "Move: " + (p.isSwimming() ? "Swim" : p.isFallFlying() ? "Glide" : p.isSprinting() ? "Sprint" : p.isSneaking() ? "Sneak" : p.isOnGround() ? "Ground" : "Air")));
        out.add(new TelemetryHud("Direction", "Direction göstergesi", 860, p -> "Direction: " + direction(p.getYaw())));
        out.add(new TelemetryHud("LookAngle", "LookAngle göstergesi", 870, p -> "Look: " + (p.getPitch() < -45 ? "Up" : p.getPitch() > 45 ? "Down" : "Level")));
        out.add(new TelemetryHud("Moving", "Moving göstergesi", 880, p -> "Moving: " + yn(p.getVelocity().horizontalLengthSquared() > 0.0001)));
        out.add(new TelemetryHud("Idle", "Idle göstergesi", 890, p -> "Idle: " + yn(p.getVelocity().horizontalLengthSquared() <= 0.0001)));
        out.add(new TelemetryHud("Alive", "Alive göstergesi", 900, p -> "Alive: " + yn(p.isAlive())));
        out.add(new TelemetryHud("Dead", "Dead göstergesi", 910, p -> "Dead: " + yn(!p.isAlive())));
        out.add(new TelemetryHud("InVehicle", "InVehicle göstergesi", 920, p -> "Vehicle: " + yn(p.hasVehicle())));
        out.add(new TelemetryHud("Climbing", "Climbing göstergesi", 930, p -> "Climbing: " + yn(p.isClimbing())));
        out.add(new TelemetryHud("Wet", "Wet göstergesi", 940, p -> "Wet: " + yn(p.isWet())));
        out.add(new TelemetryHud("Sleeping", "Sleeping göstergesi", 950, p -> "Sleeping: " + yn(p.isSleeping())));
        out.add(new TelemetryHud("UsingItem", "UsingItem göstergesi", 960, p -> "Using Item: " + yn(p.isUsingItem())));
        out.add(new TelemetryHud("AttackCooldown", "AttackCooldown göstergesi", 970, p -> "Attack CD: " + f(p.getAttackCooldownProgress(0))));
        out.add(new TelemetryHud("MainDamage", "MainDamage göstergesi", 980, p -> "Main Damage: " + p.getMainHandStack().getDamage()));
        out.add(new TelemetryHud("MainMaxDamage", "MainMaxDamage göstergesi", 990, p -> "Main Max: " + p.getMainHandStack().getMaxDamage()));
        out.add(new TelemetryHud("OffDamage", "OffDamage göstergesi", 1000, p -> "Off Damage: " + p.getOffHandStack().getDamage()));
        out.add(new TelemetryHud("OffMaxDamage", "OffMaxDamage göstergesi", 1010, p -> "Off Max: " + p.getOffHandStack().getMaxDamage()));
        out.add(new TelemetryHud("MainDurability", "MainDurability göstergesi", 1020, p -> "Main Durability: " + durability(p.getMainHandStack())));
        out.add(new TelemetryHud("OffDurability", "OffDurability göstergesi", 1030, p -> "Off Durability: " + durability(p.getOffHandStack())));
        return out;
    }
}
