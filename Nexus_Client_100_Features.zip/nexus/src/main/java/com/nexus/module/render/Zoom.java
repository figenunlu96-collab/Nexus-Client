package com.nexus.module.render;

import com.nexus.module.Category;
import com.nexus.module.Module;
import com.nexus.setting.NumberSetting;
import org.lwjgl.glfw.GLFW;

public class Zoom extends Module {
    private final NumberSetting fov = add(new NumberSetting("FOV", 30, 5, 70, 1));
    private int old = 70;

    public Zoom() {
        super("Zoom", "Yakınlaştırır", Category.RENDER);
        setKey(GLFW.GLFW_KEY_C);
    }

    @Override protected void onEnable() { old = mc.options.getFov().getValue(); }

    @Override
    public void onTick() { mc.options.getFov().setValue(fov.get().intValue()); }

    @Override
    protected void onDisable() { mc.options.getFov().setValue(old); }
}
