package com.nexus.module.movement;

import com.nexus.module.Category;
import com.nexus.module.Module;
import net.minecraft.client.network.ClientPlayerEntity;

public class AutoSprint extends Module {
    public AutoSprint() {
        super("AutoSprint", "Otomatik koşar", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        if (mc.options.forwardKey.isPressed() && !p.isSneaking() && !p.horizontalCollision) {
            p.setSprinting(true);
        }
    }
}
