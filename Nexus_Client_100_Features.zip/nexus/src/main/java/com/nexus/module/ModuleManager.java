package com.nexus.module;

import com.nexus.module.combat.*;
import com.nexus.module.hud.Huds;
import com.nexus.module.hud.Info;
import com.nexus.module.hud.Overlays;
import com.nexus.module.world.AutoTorch;
import com.nexus.module.world.Nuker;
import com.nexus.module.world.Scaffold;
import com.nexus.module.movement.*;
import com.nexus.module.player.*;
import com.nexus.module.render.Fullbright;
import com.nexus.module.render.FovChanger;
import com.nexus.module.render.Zoom;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    private final List<Module> modules = new ArrayList<>();

    public ModuleManager() {
        // COMBAT
        register(new AutoTotem());
        register(new AutoArmor());
        register(new KillAura());
        register(new TriggerBot());
        register(new AimAssist());
        register(new AutoClicker());
        register(new Surround());
        register(new AutoWeapon());
        register(new AutoBlock());
        // MOVEMENT
        register(new Fly());
        register(new Speed());
        register(new NoFall());
        register(new AutoSprint());
        register(new Step());
        register(new HighJump());
        register(new LongJump());
        register(new AirJump());
        register(new Jesus());
        register(new Spider());
        register(new AutoWalk());
        register(new Dolphin());
        register(new Glide());
        register(new AutoJump());
        register(new SafeWalk());
        register(new Sneak());
        register(new ElytraFly());
        register(new AutoSwim());
        register(new Bhop());
        register(new FastFall());
        register(new FastLadder());
        register(new BoatFly());
        // PLAYER
        register(new AutoEat());
        register(new AutoRespawn());
        register(new AntiAFK());
        register(new AutoTool());
        register(new ChestStealer());
        register(new AutoReplenish());
        register(new AutoFish());
        register(new AutoMine());
        register(new ItemThrower());
        // WORLD
        register(new Scaffold());
        register(new Nuker());
        register(new AutoTorch());
        // RENDER
        register(new Fullbright());
        register(new Zoom());
        register(new FovChanger());
        // HUD
        register(new Huds.Fps());
        register(new Huds.Cps());
        register(new Huds.Ping());
        register(new Huds.Coords());
        register(new Huds.SpeedHud());
        register(new Huds.Clock());
        register(new Overlays.TotemCounter());
        register(new Overlays.CrystalCounter());
        register(new Overlays.PotionCounter());
        register(new Overlays.EntityCounter());
        register(new Overlays.PlayerCounter());
        register(new Overlays.Session());
        register(new Overlays.WorldTime());
        register(new Overlays.ServerInfoHud());
        register(new Overlays.FallDistanceHud());
        register(new Overlays.ArmorHud());
        register(new Overlays.PotionHud());
        register(new Overlays.TargetHud());
        register(new Overlays.Keystrokes());
        register(new Overlays.CooldownBar());
        register(new Overlays.CustomCrosshair());
        register(new Info.DeathLocation());
        register(new Info.Direction());
        register(new Info.DayCounter());

        // 100 additional configurable telemetry HUD features
        for (Module telemetry : com.nexus.module.hud.TelemetryPack.create()) register(telemetry);
    }

    private void register(Module m) { modules.add(m); }

    public List<Module> all() { return modules; }

    public List<Module> byCategory(Category c) {
        List<Module> out = new ArrayList<>();
        for (Module m : modules) if (m.category == c) out.add(m);
        return out;
    }

    public Module byName(String name) {
        for (Module m : modules) if (m.name.equalsIgnoreCase(name)) return m;
        return null;
    }

    public void tick() {
        for (Module m : modules) if (m.isEnabled()) m.onTick();
    }
}
