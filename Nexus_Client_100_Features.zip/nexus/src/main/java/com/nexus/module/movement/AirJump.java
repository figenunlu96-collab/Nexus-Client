package com.nexus.module.movement;

import com.nexus.module.Category;
import com.nexus.module.Module;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

public class AirJump extends Module {
    private boolean wasDown = false;

    public AirJump() { super("AirJump", "Havada tekrar zıplatır", Category.MOVEMENT); }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        boolean down = mc.options.jumpKey.isPressed();
        if (down && !wasDown && !p.isOnGround() && !p.isTouchingWater()) {
            Vec3d v = p.getVelocity();
            p.setVelocity(v.x, 0.42, v.z);
            p.fallDistance = 0;
        }
        wasDown = down;
    }
}
