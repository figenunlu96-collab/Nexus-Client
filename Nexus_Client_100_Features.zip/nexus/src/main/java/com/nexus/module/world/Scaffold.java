package com.nexus.module.world;

import com.nexus.module.Category;
import com.nexus.module.Module;
import com.nexus.setting.NumberSetting;
import net.minecraft.block.BlockState;
import net.minecraft.block.BlockWithEntity;
import net.minecraft.block.FallingBlock;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/** Ayağının altındaki boşluğa hotbar'daki bir bloğu otomatik koyar. */
public class Scaffold extends Module {
    private final NumberSetting delay = add(new NumberSetting("Delay", 1, 0, 10, 1));
    private int cooldown = 0;

    public Scaffold() { super("Scaffold", "Altına otomatik blok koyar", Category.WORLD); }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (cooldown > 0) { cooldown--; return; }

        BlockPos target = p.getBlockPos().down();
        if (!mc.world.getBlockState(target).isReplaceable()) return;

        int slot = findBlockSlot(p);
        if (slot < 0) return;

        for (Direction d : Direction.values()) {
            BlockPos nb = target.offset(d);
            BlockState st = mc.world.getBlockState(nb);
            if (st.isReplaceable() || st.isAir()) continue;

            Direction face = d.getOpposite();
            Vec3d hitPos = Vec3d.ofCenter(nb).add(Vec3d.of(face.getVector()).multiply(0.5));
            BlockHitResult hit = new BlockHitResult(hitPos, face, nb, false);

            int prev = p.getInventory().getSelectedSlot();
            p.getInventory().setSelectedSlot(slot);
            mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, hit);
            p.swingHand(Hand.MAIN_HAND);
            p.getInventory().setSelectedSlot(prev);
            cooldown = delay.get().intValue();
            return;
        }
    }

    private int findBlockSlot(ClientPlayerEntity p) {
        for (int i = 0; i < 9; i++) {
            ItemStack s = p.getInventory().getStack(i);
            if (s.isEmpty() || !(s.getItem() instanceof BlockItem bi)) continue;
            if (bi.getBlock() instanceof FallingBlock || bi.getBlock() instanceof BlockWithEntity) continue;
            return i;
        }
        return -1;
    }
}
