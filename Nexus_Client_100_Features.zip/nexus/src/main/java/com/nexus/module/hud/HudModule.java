package com.nexus.module.hud;

import com.nexus.module.Category;
import com.nexus.module.Module;
import com.nexus.setting.ModeSetting;
import com.nexus.setting.NumberSetting;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

/** HUD bileşeni. Varsayılan olarak tek satır metin çizer; özel çizim için render() override edilir. */
public abstract class HudModule extends Module {
    public final NumberSetting x = add(new NumberSetting("X", 4, 0, 1000, 1));
    public final NumberSetting y = add(new NumberSetting("Y", 40, 0, 2000, 1));
    public final ModeSetting color = add(new ModeSetting("Color", "Blue", "Blue", "Purple", "White", "Green", "Red"));

    protected HudModule(String name, String desc, int defaultY) {
        super(name, desc, Category.HUD);
        y.set((double) defaultY);
    }

    public String text() { return ""; }

    public void render(DrawContext ctx, TextRenderer tr) {
        ctx.drawTextWithShadow(tr, text(), x.get().intValue(), y.get().intValue(), argb());
    }

    public int argb() {
        return switch (color.get()) {
            case "Purple" -> 0xFFB44CFF;
            case "White" -> 0xFFFFFFFF;
            case "Green" -> 0xFF55FF77;
            case "Red" -> 0xFFFF4466;
            default -> 0xFF3DDCFF;
        };
    }
}
