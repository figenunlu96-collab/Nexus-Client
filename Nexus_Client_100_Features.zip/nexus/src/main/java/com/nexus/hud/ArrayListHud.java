package com.nexus.hud;

import com.nexus.NexusClient;
import com.nexus.module.Module;
import com.nexus.module.combat.AutoTotem;
import com.nexus.module.hud.HudModule;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.util.Comparator;
import java.util.List;

public class ArrayListHud {
    public static void init() {
        HudRenderCallback.EVENT.register((DrawContext ctx, net.minecraft.client.render.RenderTickCounter tick) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.options.hudHidden) return;
            TextRenderer tr = mc.textRenderer;

            ctx.drawTextWithShadow(tr, "Nexus Client", 4, 4, 0xFFB44CFF);

            Module at = NexusClient.modules.byName("AutoTotem");
            if (at != null && at.isEnabled()) {
                int n = AutoTotem.totemCount;
                int color = n == 0 ? 0xFFFF4466 : n <= 2 ? 0xFFFFCC33 : 0xFF3DDCFF;
                ctx.drawTextWithShadow(tr, "Totem: " + n, 4, 16, color);
            }

            // HUD bileşenleri (FPS, CPS, Ping, XYZ, ...)
            for (Module m : NexusClient.modules.all()) {
                if (m instanceof HudModule h && h.isEnabled()) {
                    h.render(ctx, tr);
                }
            }

            // aktif modül listesi
            List<Module> on = NexusClient.modules.all().stream()
                .filter(Module::isEnabled)
                .filter(m -> !(m instanceof HudModule))
                .sorted(Comparator.comparingInt((Module m) -> -tr.getWidth(label(m))))
                .toList();

            int w = ctx.getScaledWindowWidth();
            int y = 4;
            for (Module m : on) {
                String t = label(m);
                ctx.drawTextWithShadow(tr, t, w - tr.getWidth(t) - 4, y, 0xFF3DDCFF);
                y += tr.fontHeight + 2;
            }
        });
    }

    private static String label(Module m) {
        String info = m.getInfo();
        return info.isEmpty() ? m.name : m.name + " [" + info + "]";
    }
}
