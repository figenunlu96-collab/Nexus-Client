package com.nexus.setting;

public class BooleanSetting extends Setting<Boolean> {
    public BooleanSetting(String name, boolean def) { super(name, def); }
    public void toggle() { value = !value; }
}
