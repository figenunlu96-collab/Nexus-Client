package com.nexus.setting;

public class NumberSetting extends Setting<Double> {
    public final double min, max, step;

    public NumberSetting(String name, double def, double min, double max, double step) {
        super(name, def);
        this.min = min; this.max = max; this.step = step;
    }

    @Override
    public void set(Double v) { this.value = Math.max(min, Math.min(max, v)); }

    public float f() { return value.floatValue(); }
}
