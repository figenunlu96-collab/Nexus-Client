package com.nexus.gui;

import com.nexus.NexusClient;
import com.nexus.config.ConfigManager;
import com.nexus.config.ProfileManager;
import com.nexus.module.Category;
import com.nexus.module.Module;
import com.nexus.setting.*;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.*;

public class ClickGui extends Screen {
    private static final int W = 112, HEADER = 16, ROW = 14, SROW = 12;

    // renkler (ARGB): siyah / koyu gri / neon mor / elektrik mavisi
    private static final int BG        = 0xEE0B0B0F;
    private static final int HEAD      = 0xFF1B0B33;
    private static final int ROW_OFF   = 0xEE15151C;
    private static final int ROW_ON    = 0xEE3A1A6E;
    private static final int SET_BG    = 0xEE101018;
    private static final int PURPLE    = 0xFFB44CFF;
    private static final int BLUE      = 0xFF3DDCFF;
    private static final int WHITE     = 0xFFE8E8F0;
    private static final int GRAY      = 0xFF8A8A99;

    /** Pencere konumları oturum boyunca korunur. */
    private static final Map<Category, int[]> POS = new LinkedHashMap<>(); // {x, y, open}
    private static final Set<Module> EXPANDED = new HashSet<>();

    private enum Type { HEADER, MODULE, SETTING, PROFILE }
    private record Hit(int x, int y, int w, int h, Type type, Category cat, Module mod, Setting<?> set, String name) {}

    private final List<Hit> hits = new ArrayList<>();
    private Category draggingWin = null;
    private NumberSetting slider = null;
    private Hit sliderHit = null;
    private Module binding = null;

    public ClickGui() {
        super(Text.literal("Nexus ClickGUI"));
        int i = 0;
        for (Category c : Category.values()) {
            if (NexusClient.modules.byCategory(c).isEmpty()) continue;
            POS.computeIfAbsent(c, k -> new int[]{10 + (POS.size()) * (W + 8), 44, 1});
            i++;
        }
    }

    @Override public boolean shouldPause() { return false; }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        TextRenderer tr = this.textRenderer;
        hits.clear();

        ctx.drawTextWithShadow(tr, "NEXUS CLIENT  -  ULTIMATE MINECRAFT EXPERIENCE", 10, 8, PURPLE);
        ctx.drawTextWithShadow(tr, "Sol tık: aç/kapat | Sağ tık: ayarlar | Orta tık: keybind | RShift/ESC: kapat",
                10, this.height - 12, GRAY);

        // PvP profil butonları
        int px = 10;
        for (String pn : ProfileManager.names()) {
            int pw = tr.getWidth(pn) + 12;
            boolean act = pn.equals(ProfileManager.active);
            ctx.fill(px, 22, px + pw, 36, act ? ROW_ON : ROW_OFF);
            if (act) ctx.fill(px, 34, px + pw, 36, BLUE);
            ctx.drawTextWithShadow(tr, pn, px + 6, 26, act ? WHITE : GRAY);
            hits.add(new Hit(px, 22, pw, 14, Type.PROFILE, null, null, null, pn));
            px += pw + 4;
        }
        ctx.drawTextWithShadow(tr, "Profil: sol tık yükle, sağ tık kaydet", px + 6, 26, GRAY);

        for (Map.Entry<Category, int[]> e : POS.entrySet()) {
            Category cat = e.getKey();
            int[] p = e.getValue();
            int x = p[0], y = p[1];

            ctx.fill(x, y, x + W, y + HEADER, HEAD);
            ctx.fill(x, y + HEADER - 1, x + W, y + HEADER, PURPLE);
            ctx.drawTextWithShadow(tr, cat.name(), x + 5, y + 4, PURPLE);
            hits.add(new Hit(x, y, W, HEADER, Type.HEADER, cat, null, null, null));
            y += HEADER;

            if (p[2] == 0) continue;

            for (Module m : NexusClient.modules.byCategory(cat)) {
                boolean on = m.isEnabled();
                ctx.fill(x, y, x + W, y + ROW, on ? ROW_ON : ROW_OFF);
                if (on) ctx.fill(x, y, x + 2, y + ROW, BLUE);

                String label = m.name;
                ctx.drawTextWithShadow(tr, label, x + 6, y + 3, on ? WHITE : GRAY);

                String right = binding == m ? "..." : keyName(m.getKey());
                if (!right.isEmpty()) {
                    ctx.drawTextWithShadow(tr, right, x + W - tr.getWidth(right) - 4, y + 3, binding == m ? BLUE : GRAY);
                }
                hits.add(new Hit(x, y, W, ROW, Type.MODULE, cat, m, null, null));
                y += ROW;

                if (EXPANDED.contains(m)) {
                    for (Setting<?> s : m.getSettings()) {
                        ctx.fill(x, y, x + W, y + SROW, SET_BG);
                        drawSetting(ctx, tr, s, x, y);
                        hits.add(new Hit(x, y, W, SROW, Type.SETTING, cat, m, s, null));
                        y += SROW;
                    }
                }
            }
            ctx.fill(x, y, x + W, y + 1, PURPLE);
        }
    }

    private void drawSetting(DrawContext ctx, TextRenderer tr, Setting<?> s, int x, int y) {
        if (s instanceof BooleanSetting b) {
            ctx.drawTextWithShadow(tr, b.name, x + 8, y + 2, WHITE);
            String v = b.get() ? "ON" : "OFF";
            ctx.drawTextWithShadow(tr, v, x + W - tr.getWidth(v) - 4, y + 2, b.get() ? BLUE : GRAY);
        } else if (s instanceof NumberSetting n) {
            double frac = (n.get() - n.min) / (n.max - n.min);
            ctx.fill(x + 6, y + SROW - 3, x + 6 + (int) ((W - 12) * frac), y + SROW - 1, PURPLE);
            ctx.drawTextWithShadow(tr, n.name, x + 8, y + 1, WHITE);
            String v = fmt(n.get());
            ctx.drawTextWithShadow(tr, v, x + W - tr.getWidth(v) - 4, y + 1, BLUE);
        } else if (s instanceof ModeSetting md) {
            ctx.drawTextWithShadow(tr, md.name, x + 8, y + 2, WHITE);
            ctx.drawTextWithShadow(tr, md.get(), x + W - tr.getWidth(md.get()) - 4, y + 2, BLUE);
        }
    }

    private static String fmt(double d) {
        return d == Math.floor(d) ? String.valueOf((int) d) : String.format("%.2f", d);
    }

    private static String keyName(int key) {
        if (key < 0) return "";
        String n = GLFW.glfwGetKeyName(key, 0);
        if (n != null) return n.toUpperCase();
        return switch (key) {
            case GLFW.GLFW_KEY_RIGHT_SHIFT -> "RSHIFT";
            case GLFW.GLFW_KEY_LEFT_SHIFT -> "LSHIFT";
            case GLFW.GLFW_KEY_SPACE -> "SPACE";
            default -> "K" + key;
        };
    }

    private Hit hitAt(double mx, double my) {
        for (Hit h : hits) {
            if (mx >= h.x && mx < h.x + h.w && my >= h.y && my < h.y + h.h) return h;
        }
        return null;
    }

    private void updateSlider(double mx) {
        if (slider == null || sliderHit == null) return;
        double frac = Math.max(0, Math.min(1, (mx - sliderHit.x - 6) / (double) (W - 12)));
        double v = slider.min + frac * (slider.max - slider.min);
        v = Math.round(v / slider.step) * slider.step;
        slider.set(v);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        Hit h = hitAt(click.x(), click.y());
        if (h == null) return super.mouseClicked(click, doubled);
        int btn = click.button();

        switch (h.type) {
            case HEADER -> {
                if (btn == 0) draggingWin = h.cat;
                else if (btn == 1) { int[] p = POS.get(h.cat); p[2] = p[2] == 0 ? 1 : 0; }
            }
            case MODULE -> {
                if (btn == 0) { h.mod.toggle(); ConfigManager.save(); }
                else if (btn == 1) { if (!EXPANDED.remove(h.mod)) EXPANDED.add(h.mod); }
                else if (btn == 2) binding = h.mod;
            }
            case PROFILE -> {
                if (btn == 0) ProfileManager.switchTo(h.name);
                else if (btn == 1) ProfileManager.saveCurrent(h.name);
            }
            case SETTING -> {
                if (h.set instanceof BooleanSetting b && btn == 0) { b.toggle(); ConfigManager.save(); }
                else if (h.set instanceof ModeSetting md && btn == 0) { md.cycle(); ConfigManager.save(); }
                else if (h.set instanceof NumberSetting n && btn == 0) { slider = n; sliderHit = h; updateSlider(click.x()); }
            }
        }
        return true;
    }

    @Override
    public boolean mouseDragged(Click click, double dx, double dy) {
        if (draggingWin != null) {
            int[] p = POS.get(draggingWin);
            p[0] += (int) dx;
            p[1] += (int) dy;
            return true;
        }
        if (slider != null) { updateSlider(click.x()); return true; }
        return super.mouseDragged(click, dx, dy);
    }

    @Override
    public boolean mouseReleased(Click click) {
        if (slider != null) ConfigManager.save();
        draggingWin = null;
        slider = null;
        sliderHit = null;
        return super.mouseReleased(click);
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        int key = input.key();
        if (binding != null) {
            binding.setKey(key == GLFW.GLFW_KEY_ESCAPE ? -1 : key);
            binding = null;
            ConfigManager.save();
            return true;
        }
        if (key == GLFW.GLFW_KEY_RIGHT_SHIFT || key == GLFW.GLFW_KEY_ESCAPE) {
            this.close();
            return true;
        }
        return super.keyPressed(input);
    }
}
