package com.nexus;

import com.nexus.config.ConfigManager;
import com.nexus.gui.ClickGui;
import com.nexus.hud.ArrayListHud;
import com.nexus.module.Module;
import com.nexus.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

public class NexusClient implements ClientModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("NexusClient");
    public static ModuleManager modules;

    private final Map<Module, Boolean> keyDown = new HashMap<>();
    private boolean guiKeyWas = false;

    @Override
    public void onInitializeClient() {
        modules = new ModuleManager();
        ConfigManager.load();
        ArrayListHud.init();

        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
        ClientLifecycleEvents.CLIENT_STOPPING.register(c -> ConfigManager.save());

        LOGGER.info("Nexus Client yüklendi: {} modül", modules.all().size());
    }

    private void onTick(MinecraftClient mc) {
        if (mc.player == null) return;

        // keybind polling (sohbet/menü açıkken çalışmaz)
        if (mc.currentScreen == null) {
            long handle = mc.getWindow().getHandle();
            boolean gk = GLFW.glfwGetKey(handle, GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
            if (gk && !guiKeyWas) mc.setScreen(new ClickGui());
            guiKeyWas = gk;
            for (Module m : modules.all()) {
                int key = m.getKey();
                if (key < 0) continue;
                boolean down = GLFW.glfwGetKey(handle, key) == GLFW.GLFW_PRESS;
                boolean was = keyDown.getOrDefault(m, false);
                if (down && !was) {
                    m.toggle();
                    mc.player.sendMessage(Text.literal("§d[Nexus] §f" + m.name + (m.isEnabled() ? " §aAÇIK" : " §cKAPALI")), true);
                    ConfigManager.save();
                }
                keyDown.put(m, down);
            }
        }

        modules.tick();
    }
}
